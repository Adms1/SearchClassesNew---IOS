//
//  SCTableCell.swift
//  Search Classes_New
//
//  Created by ADMS on 26/09/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

@objc protocol TableCellDelegate {
    @objc optional func tappedOn_Session_Location_Rate(_ tag: NSInteger, _ strType:String)
    @objc optional func tappedOnRating(_ tag: NSInteger)
    @objc optional func tappedOn_Mail_Location_Rate(_ tag: NSInteger, _ superViewTag:NSInteger)
}

class TableCell: UITableViewCell {
    
    @IBOutlet var customView: UIView!
    @IBOutlet var bottomConstrain: NSLayoutConstraint!
    
    @IBOutlet var addressTopConstrain: NSLayoutConstraint!
    @IBOutlet var lblDescription: UILabel!
    @IBOutlet var viewline: UIView!
    
    var delegate: TableCellDelegate!
    var searchValues:((String) -> Void)?
    var changeValues:((Bool) -> Void)?
    
    @IBOutlet var lbl1: UILabel!
    @IBOutlet var lbl2: UILabel!
    @IBOutlet var lbl3: UILabel!
    @IBOutlet var lbl4: UILabel!
    @IBOutlet var lbl5: UILabel!
    @IBOutlet var lbl6: UILabel!
    @IBOutlet var lbl7: UILabel!
    @IBOutlet var v1: UIView!
    @IBOutlet var v2: UIView!
    @IBOutlet var v3: UIView!
    @IBOutlet var v4: UIView!
    @IBOutlet var v5: UIView!
    @IBOutlet var v6: UIView!
    @IBOutlet var v7: UIView!
    @IBOutlet var c1: NSLayoutConstraint!
    @IBOutlet var c2: NSLayoutConstraint!
    @IBOutlet var c3: NSLayoutConstraint!
    @IBOutlet var c4: NSLayoutConstraint!
    @IBOutlet var c5: NSLayoutConstraint!
    @IBOutlet var c6: NSLayoutConstraint!
    @IBOutlet var c7: NSLayoutConstraint!
    
    @IBOutlet weak var searchBar: UISearchBar! {
        didSet {
            searchBar.change(textFont: FontHelper.regular(size: 14))
        }
    }
    
    override func awakeFromNib() {
        if(customView != nil){
            TableCell.addViews(customView)
        }
    }
    
    class func addViews(_ subView:UIView)
    {
        let padding:CGFloat = 30
        let lblWidth = (UIScreen.main.bounds.width - padding)/7
        
        for (i,day) in Constants.arrDays.enumerated() {
            
            let lblDay:UILabel = UILabel(frame:CGRect(x: (lblWidth*CGFloat(i)) + ((lblWidth/2) - 10), y: 5, width: 20, height: 20))
            lblDay.backgroundColor = GetColor.headerColor
            lblDay.textColor = .white
            lblDay.text = day
            lblDay.tag = i+1
            lblDay.textAlignment = .center
            lblDay.font = FontHelper.semibold(size: DeviceType.isIphone5 ? 11 : 13)
            
            let lblTime:UILabel = UILabel(frame:CGRect(x: (lblWidth*CGFloat(i)), y: 30, width: lblWidth, height: 15))
            lblTime.textColor = .black
            lblTime.text = "0:00"
            lblTime.textAlignment = .center
            lblTime.tag = (i+1) * 10
            lblTime.font = FontHelper.regular(size: DeviceType.isIphone5 ? 8 : 10)
            
            let lblDuration:UILabel = UILabel(frame:CGRect(x: (lblWidth*CGFloat(i)), y: 45, width: lblWidth, height: 15))
            lblDuration.textColor = GetColor.radioColorRed
            lblDuration.text = "0:00"
            lblDuration.textAlignment = .center
            lblDuration.tag = (i+1) * 100
            lblDuration.font = FontHelper.regular(size: DeviceType.isIphone5 ? 8 : 10)
            
            subView.addSubview(lblDay)
            subView.addSubview(lblTime)
            subView.addSubview(lblDuration)
        }
    }
    
    func displayValues(_ strValue:String, _ searchText:String, _ dict:[String:Bool])
    {
        if let lbl = self.contentView.subviews[0] as? UILabel {
            lbl.text = strValue
            if(searchText != ""){
                lbl.attributedText = strValue.makeBoldSubString(searchText, FontHelper.bold(size: DeviceType.isIpad ? 15 :12), false, .black, .black)
            }
        }
        
        if(self.contentView.subviews.count > 1) {
            if let checkBox = self.contentView.subviews[1] as? VKCheckbox {
                checkBox.setOn(dict[strValue]!)
                if self.changeValues != nil {
                    self.changeValues!(checkBox.isOn())
                }
            }
        }
    }
    
    @objc func tapOnMailLocationRate(_ gesture:UIGestureRecognizer)
    {
        var tag = (gesture.view?.tag)!
        if(tag > 15){
            tag = tag/10
        }
        self.delegate.tappedOn_Mail_Location_Rate!(tag, (gesture.view?.superview?.superview?.superview?.tag)!)
    }
    
    @objc func tapOnSessionLocationRate(_ gesture:UIGestureRecognizer)
    {
        self.delegate.tappedOn_Session_Location_Rate!((gesture.view?.tag)!, (gesture.view?.accessibilityIdentifier)!)
    }
    
    
    @objc func tapForMakeCall(_ gesture:UIGestureRecognizer)
    {
        var tag = (gesture.view?.tag)!
        if(tag > 15){
            tag = tag/10
        }
        if let lbl = gesture.view?.superview?.viewWithTag(tag) as? UILabel {
            lbl.text!.makeCall()
        }
    }
    
    // TODO: - Coach ListData (Search Classes)
    
    func displayCoachListData(_ coachListData:CoachModel)
    {
        let arrCoachList = [coachListData.strInstituteName, coachListData.strCoachName, coachListData.strRegion, coachListData.ratingUser > 0 ? "(\(coachListData.ratingUser))" : ""]
        
        var i = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{$0 as? UILabel}) {
            
            lbl.text = arrCoachList[i]
            if(i == 2){
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(tapOnSessionLocationRate(_:)))
                lbl.accessibilityIdentifier = "Location"
                lbl.addGestureRecognizer(tapGesture)
            }
            i += 1
        }
        
        for ratingView in (self.contentView.subviews[0].subviews.flatMap{$0 as? FloatRatingView}){
            
            ratingView.rating = coachListData.rating
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(tapOnSessionLocationRate(_:)))
            ratingView.accessibilityIdentifier = "Rating"
            ratingView.addGestureRecognizer(tapGesture)
        }
        
        TableCell.displayClassDetailData(customView, coachListData.strAvailability)
    }
    
    // TODO: - Coach Details (Search Classes)
    
    func displayCoachDetails(_ ratingUserCount:Int)
    {
        var arrCoachDetailData = [selectedCoachData.strCoachName,selectedCoachData.strInstituteName, selectedCoachData.strBoard, selectedCoachData.strStandard, selectedCoachData.strSubject, selectedCoachData.strExam, selectedCoachData.strActivity, selectedCoachData.strDescription, selectedCoachData.strFullAddress, selectedCoachData.strEmail, selectedCoachData.strContactNo, ratingUserCount > 0 ? "(\(ratingUserCount))" : ""]
        
        var i = 0
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}){
            
            if(lbl.tag == i+1) {
                lbl.text = arrCoachDetailData[i]
                switch(i)
                {
                case 1:
                    lbl1.text = arrCoachDetailData[i].isEmptyStr ? nil : "Institue"
                    v1.isHidden = arrCoachDetailData[i].isEmptyStr
                    c1.constant = arrCoachDetailData[i].isEmptyStr ? -1 : 8
                    
                case 2:
                    lbl5.text = arrCoachDetailData[i].isEmptyStr ? nil : "Board"
                    v5.isHidden = arrCoachDetailData[i].isEmptyStr
                    c5.constant = arrCoachDetailData[i].isEmptyStr ? -1 : 8
                    
                case 3:
                    lbl6.text = arrCoachDetailData[i].isEmptyStr ? nil : "Standard"
                    v6.isHidden = arrCoachDetailData[i].isEmptyStr
                    c6.constant = arrCoachDetailData[i].isEmptyStr ? -1 : 8
                    
                case 4:
                    lbl7.text = arrCoachDetailData[i].isEmptyStr ? nil : "Subject"
                    v7.isHidden = arrCoachDetailData[i].isEmptyStr
                    c7.constant = arrCoachDetailData[i].isEmptyStr ? -1 : 8
                    
                case 5:
                    lbl2.text = arrCoachDetailData[i].isEmptyStr ? nil : "Entrance Exam"
                    v2.isHidden = arrCoachDetailData[i].isEmptyStr
                    c2.constant = arrCoachDetailData[i].isEmptyStr ? -1 : 8
                    
                case 6:
                    lbl3.text = arrCoachDetailData[i].isEmptyStr ? nil : "Activity"
                    v3.isHidden = arrCoachDetailData[i].isEmptyStr
                    c3.constant = arrCoachDetailData[i].isEmptyStr ? -1 : 8
                    
                case 7:
                    lbl4.text = arrCoachDetailData[i].isEmptyStr ? nil : "Description"
                    v4.isHidden = arrCoachDetailData[i].isEmptyStr
                    c4.constant = arrCoachDetailData[i].isEmptyStr ? -1 : 8
                    
                default:
                    break
                }
                
                if(i > 7)
                {
                    let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: i == 10 ? #selector(tapForMakeCall(_:)) : #selector(tapOnMailLocationRate(_:)))
                    lbl.addGestureRecognizer(tapGesture)
                }
                else if(i == 0)
                {
                    //                    let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(tapTeacherProfile(_:)))
                    //                    lbl.addGestureRecognizer(tapGesture)
                }
                i += 1
            }
        }
        
        for ratingView in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? FloatRatingView}){
            
            ratingView.rating = selectedCoachData.rating
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(tapOnMailLocationRate(_:)))
            ratingView.addGestureRecognizer(tapGesture)
        }
        
        for imgView in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UIImageView}){
            
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: imgView.tag == 110 ? #selector(tapForMakeCall(_:)) : imgView.tag == 120 ? #selector(tapForMakeCall(_:)) : #selector(tapOnMailLocationRate(_:)))
            imgView.addGestureRecognizer(tapGesture)
        }
    }
    
    // TODO: - Inquiry List Data (Search Classes)
    
    func displayInquiryDetails(_ inquiryData:SCInquiryModel)
    {
        var arrInquiryDetailData = [inquiryData.strFirstName, inquiryData.strDate, inquiryData.strBoard, inquiryData.strStandard, inquiryData.strSubject, inquiryData.strExam, inquiryData.strActivity, inquiryData.strDescription, inquiryData.strEmail, inquiryData.strPhone]
        
        var i = 0
        for lbl in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UILabel}){
            
            if(lbl.tag == i+1) {
                lbl.text = arrInquiryDetailData[i]
                switch(i)
                {
                case 2:
                    lbl1.text = arrInquiryDetailData[i].isEmptyStr ? nil : "Board"
                    v1.isHidden = arrInquiryDetailData[i].isEmptyStr
                    c1.constant = arrInquiryDetailData[i].isEmptyStr ? -1 : 8
                    
                case 3:
                    lbl2.text = arrInquiryDetailData[i].isEmptyStr ? nil : "Standard"
                    v2.isHidden = arrInquiryDetailData[i].isEmptyStr
                    c2.constant = arrInquiryDetailData[i].isEmptyStr ? -1 : 8
                    
                case 4:
                    lbl3.text = arrInquiryDetailData[i].isEmptyStr ? nil : "Subject"
                    v3.isHidden = arrInquiryDetailData[i].isEmptyStr
                    c3.constant = arrInquiryDetailData[i].isEmptyStr ? -1 : 8
                    
                case 5:
                    lbl4.text = arrInquiryDetailData[i].isEmptyStr ? nil : "Entrance Exam"
                    v4.isHidden = arrInquiryDetailData[i].isEmptyStr
                    c4.constant = arrInquiryDetailData[i].isEmptyStr ? -1 : 8
                    
                case 6:
                    lbl5.text = arrInquiryDetailData[i].isEmptyStr ? nil : "Activity"
                    v5.isHidden = arrInquiryDetailData[i].isEmptyStr
                    c5.constant = arrInquiryDetailData[i].isEmptyStr ? -1 : 8
                    
                case 7:
                    lbl6.text = arrInquiryDetailData[i].isEmptyStr ? nil : "Description"
                    v6.isHidden = arrInquiryDetailData[i].isEmptyStr
                    c6.constant = arrInquiryDetailData[i].isEmptyStr ? -1 : 8
                    
                default:
                    break
                }
                
                if(i > 7)
                {
                    let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: i == 9 ? #selector(tapForMakeCall(_:)) : #selector(tapOnMailLocationRate(_:)))
                    lbl.addGestureRecognizer(tapGesture)
                }
                i += 1
            }
        }
        
        for imgView in (self.contentView.subviews[0].subviews[0].subviews.flatMap{$0 as? UIImageView}){
            
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: imgView.tag == 100 ? #selector(tapForMakeCall(_:)) : #selector(tapOnMailLocationRate(_:)))
            imgView.addGestureRecognizer(tapGesture)
        }
    }
    
    // TODO: - Inquiry List Data (Search Classes)
    
    func displayInquiryHeaderDetails(_ inquiryData:SCInquiryModel)
    {
        var arrInquiryHeaderDetailData = [inquiryData.strFirstName, inquiryData.strDate]
        
        var i = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{$0 as? UILabel}){
            
            lbl.text = arrInquiryHeaderDetailData[i]
            i += 1
        }
    }
    
    // TODO: - Session Rating Details (Search Classes)
    
    func displayClassRatingDetails(_ classRatingModel:CoachModel)
    {
        let arrClassRatingData = [classRatingModel.strUserName, classRatingModel.strDate, "(\(classRatingModel.rating))", classRatingModel.strComment]
        
        var i = 0
        for lbl in (self.contentView.subviews[0].subviews.flatMap{$0 as? UILabel}) {
            
            if(lbl.tag != -1) {
                lbl.text = (arrClassRatingData[i].isEmptyStr) ? "-" : arrClassRatingData[i]
                
                i += 1
            }
        }
        
        for ratingView in (self.contentView.subviews[0].subviews.flatMap{$0 as? FloatRatingView}){
            ratingView.rating = classRatingModel.rating
        }
    }
    
    class func displayClassDetailData(_ timerView:UIView, _ schedule:String?)
    {
        TableCell.displayClassTimeValue(timerView, schedule)
    }
    
    class func displayClassTimeValue(_ timerView:UIView, _ schedule:String?)
    {
        // Set Session Time
        
        let arrSessionTime = schedule?.components(separatedBy: "|")
        var arrDays:[Int] = []
        var arrStartTime:[String] = []
        var arrEndTime:[String] = []
        var arrDuration:[String] = []
        
        for session in arrSessionTime! {
            let arr = session.components(separatedBy: ",")
            
            arrDays.append(Int(arr.first!)!-1 == 0 ? 7 : Int(arr.first!)!-1)
            arrStartTime.append(arr[1].components(separatedBy: "-").first!)
            arrEndTime.append(arr[1].components(separatedBy: "-").last!)
            
            let result = calculateTimeDifference(arr[1].components(separatedBy: "-")[0], arr[1].components(separatedBy: "-")[1], ErrorType.validTime.rawValue)
            if(result.0)
            {
                if(result.1 != 0){
                    if(result.2 != 0){
                        let mins = result.2! < 9 ? "0\(result.2!)" : "\(result.2!)"
                        arrDuration.append("\(result.1!):\(mins) hrs")
                    }else {
                        arrDuration.append("\(result.1!):00 hrs")
                    }
                } else if(result.2 != 0){
                    let mins = result.2! < 9 ? "0\(result.2!)" : "\(result.2!)"
                    arrDuration.append("0:\(mins) hrs")
                } else{
                    arrDuration.append("0 hrs")
                }
            }else{
                arrDuration.append("0:00 hrs")
            }
        }
        
        for lbl in (timerView.subviews.flatMap{$0 as? UILabel})
        {
            let lblTime = timerView.viewWithTag(lbl.tag * 10) as? UILabel
            let lblDuration = timerView.viewWithTag(lbl.tag * 100) as? UILabel
            
            if(arrDays.contains(lbl.tag)){
                lbl.alpha = 1.0
                
                let idx:NSInteger = arrDays.index(of: lbl.tag)!
                lblTime?.alpha = 1.0
                lblTime?.text = arrStartTime[idx]
                
                lblDuration?.alpha = 1.0
                lblDuration?.textColor = lblTime?.textColor
                lblDuration?.text = arrEndTime[idx]
            }
            else if(lbl.tag < 10) {
                lbl.alpha = 0.2
                
                lblTime?.alpha = 0.2
                lblTime?.text = nil
                
                lblDuration?.alpha = 0.2
                lblDuration?.text = nil
            }
        }
    }
}

class CollectionCell: UICollectionViewCell {
    
    @IBOutlet var trealingConstant:NSLayoutConstraint!
    @IBOutlet var imgPhotos:UIImageView!
}
