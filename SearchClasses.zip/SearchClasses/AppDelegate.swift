//
//  AppDelegate.swift
//  Search Classes
//
//  Created by ADMS on 05/03/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import Firebase
import Fabric

var bundleName               = Bundle.main.infoDictionary?["CFBundleName"] as! String

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    var navigationController:UINavigationController!
    var restrictRotation:Bool = false
    var googleMapKey = "AIzaSyDUkbo2JeiYXYIg1WSMaMkN-8_IL7pVrks"
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        if(coachID != nil && coachLoginID != nil){
            self.makeAppRootController(SCViewControllerType.scInquiry.rawValue)
        }else if(coachID != nil && coachLoginID == nil){
            coachType = .register
            self.makeAppRootController(SCViewControllerType.scAddress.rawValue)
        }
        
        FirebaseApp.configure()
        Fabric.sharedSDK().debug = true
        
        return true
    }
    
    func makeAppRootController(_ strIdentifier:String)
    {
        let viewController = Constants.storyBoard.instantiateViewController(withIdentifier: strIdentifier)
        navigationController = UINavigationController.init(rootViewController: viewController)
        navigationController.isNavigationBarHidden = true
        self.window?.rootViewController = navigationController
    }
    
    func isUpdateAvailable() throws -> (Bool,String,String) {
        guard let info = Bundle.main.infoDictionary,
            let currentVersion = info["CFBundleShortVersionString"] as? String,
            let proName = info["CFBundleDisplayName"] as? String,
            let identifier = info["CFBundleIdentifier"] as? String,
            let url = URL(string: "http://itunes.apple.com/lookup?bundleId=\(identifier)") else {
                throw VersionError.invalidBundleInfo
        }
        let data = try Data(contentsOf: url)
        guard let json = try JSONSerialization.jsonObject(with: data, options: [.allowFragments]) as? [String: Any] else {
            throw VersionError.invalidResponse
        }
        if let result = (json["results"] as? [Any])?.first as? [String: Any], let version = result["version"] as? String {
            return (version != currentVersion, proName, version)
        }
        throw VersionError.invalidResponse
    }
    
    func setupForUpdate(_ strAppName:String, _ strAppVersion:String)
    {
        let alert = UIAlertController(title: CommonMessage.appUpdateTitle, message: CommonMessage.appUpdateMsg.replacingOccurrences(of: "{}", with: strAppName).replacingOccurrences(of: "()", with: strAppVersion), preferredStyle: .alert)
        let yesButton = UIAlertAction(title: "Later", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            exit(0)
        })
        let noButton = UIAlertAction(title: "Update", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            let url:URL = URL(string: "itms://itunes.apple.com/us/app/apple-store/id1412611094?mt=8")!
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        })
        alert.addAction(yesButton)
        alert.addAction(noButton)
        self.window?.windowLevel = UIWindowLevelAlert + 1
        self.window?.makeKeyAndVisible()
        self.window?.rootViewController?.present(alert, animated: true, completion: { })
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        DispatchQueue.global().async {
            do {
                let update = try self.isUpdateAvailable().0
                if(update){
                    self.setupForUpdate(try self.isUpdateAvailable().1, try self.isUpdateAvailable().2)
                }
            } catch {
                print(error)
            }
        }
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
}

