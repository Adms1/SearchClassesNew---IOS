//
//  SCServiceModel.swift
//  Search Classes_New
//
//  Created by ADMS on 07/09/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

extension String {
    
    var isEmptyStr:Bool{
        return self.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines).isEmpty
    }
}

class SCLoginModel {
    
    let strEmailAddress :String?
    let strPassword     :String?
    
    class func loginValidation(_ mirrored_object:Mirror, _ errorType:[ErrorType])  -> (Bool,Int)
    {
        for (index, attr) in mirrored_object.children.enumerated() {
            let value: String? = attr.value as? String
            
            if((value?.isEmptyStr)!){
                showToast(errorType[index].rawValue)
                return (false,index)
                
            } else {
                switch(index)
                {
                case 0:
                    if(!(value?.isValidEmail())!){
                        showToast(ErrorType.inValidEmail.rawValue)
                        return (false,index)
                    }
                    
                case 1:
                    if((value?.count)! < 4) {
                        showToast(ErrorType.inValidPassword.rawValue)
                        return (false,index)
                    }
                    
                default:
                    break
                }
            }
        }
        return (true,0)
    }
    
    init(eid:String, pwd:String) {
        
        self.strEmailAddress = eid
        self.strPassword     = pwd
    }
}

class ForgotPasswordModel {
    
    let strEmailAddress :String?
    
    class func forgotPasswordValidation(_ strEmailId:String, _ errorType:ErrorType) -> Bool
    {
        if strEmailId.isEmptyStr {
            showToast(errorType.rawValue)
            return false
        }
        else if(!(strEmailId.isValidEmail())){
            showToast(ErrorType.inValidEmail.rawValue)
            return false
        }
        return true
    }
    
    init(eid:String) {
        self.strEmailAddress = eid
    }
}

class SCRegisterModel {
    
    var strFirstName    :String = ""
    var strLastName     :String = ""
    var strInstitueName :String = ""
    var strEmailAddress :String = ""
    var strPassword     :String = ""
    var strPhoneNumber  :String = ""
    var strDateOfBirth  :String = ""
    var strGenderID     :String = ""
    
    class func registerValidation(_ mirrored_object:Mirror, _ errorType:[ErrorType], _ hasInstitute:Bool) -> (Bool,Int)
    {
        for (index, attr) in mirrored_object.children.enumerated() {
            let value: String? = attr.value as? String
            
            if((value?.isEmptyStr)!){
                if(!hasInstitute) {
                    if(index != 2) {
                        showToast(errorType[index].rawValue)
                        return (false,index)
                    }
                }else {
                    showToast(errorType[index].rawValue)
                    return (false,index)
                }
            }else {
                switch(index)
                {
                case 3:
                    if(!(value?.isValidEmail())!){
                        showToast(ErrorType.inValidEmail.rawValue)
                        return (false,index)
                    }
                case 4:
                    if((value?.count)! < 4) {
                        showToast(ErrorType.inValidPassword.rawValue)
                        return (false,index)
                    }
                case 5:
                    if((value?.count)! < 10) {
                        showToast(ErrorType.inValidPhone.rawValue)
                        return (false,index)
                    }
                default:
                    break
                }
            }
        }
        return (true,0)
    }
    
    init(fname:String, lname:String, institueName:String, eid:String, pwd:String, pno:String, dob:String, gid:String) {
        
        self.strFirstName    = fname
        self.strLastName     = lname
        self.strInstitueName = institueName
        self.strEmailAddress = eid
        self.strPassword     = pwd
        self.strPhoneNumber  = pno
        self.strDateOfBirth  = dob
        self.strGenderID     = gid
    }
}

class SCAddressModel {
    
    var strAddressLine1     :String = ""
    var strAddressLine2     :String = ""
    var strArea             :String = ""
    var strCity             :String = ""
    var strState            :String = ""
    var strZipCode          :String = ""
    
    class func addressValidation(_ mirrored_object:Mirror, _ errorType:[ErrorType]) -> (Bool,Int)
    {
        for (index, attr) in mirrored_object.children.enumerated() {
            let value: String? = attr.value as? String
            
            if((value?.isEmptyStr)!){
                if(index != 1) {
                    showToast(errorType[index].rawValue)
                    return (false,index)
                }
            }
        }
        return (true,0)
    }
    
    init(addressLine1:String, addressLine2:String, area:String, city:String, state:String, zipCode:String) {
        
        self.strAddressLine1    = addressLine1
        self.strAddressLine2    = addressLine2
        self.strArea            = area
        self.strCity            = city
        self.strState           = state
        self.strZipCode         = zipCode
    }
}

class CoachModel {
    
    var strCoachID          :String = ""
    var strCoachName        :String = ""
    var strInstituteName    :String = ""
    var strBoard            :String = ""
    var strStandard         :String = ""
    var strSubject          :String = ""
    var strActivity         :String = ""
    var strExam             :String = ""
    var strAddress1         :String = ""
    var strAddress2         :String = ""
    var strRegion           :String = ""
    var strCity             :String = ""
    var strState            :String = ""
    var strCountry          :String = ""
    var strZipCode          :String = ""
    var strAvailability     :String? = nil
    var strDuration         :String? = nil
    var strHasInstiture     :String = ""
    var strDescription      :String = ""
    var strEmail            :String = ""
    var strContactNo        :String = ""
    var ratingUser          :Int = 0
    var rating              :Double = 0
    var strComment          :String = ""
    var strUserName         :String = ""
    var strDate             :String = ""
    
    init(coachId:String, coachName:String, institueName:String, board:String, std:String, subject:String, activity:String, exam:String, address1:String, address2:String, region:String, city:String, state:String, country:String, zipCode:String, availability:String?, duration:String?, hasInstitute:String, description:String, email:String, contactNo:String, ratingUser:Int, rating:Double) {
        
        self.strCoachID           = coachId
        self.strCoachName         = coachName
        self.strInstituteName     = institueName
        self.strBoard             = board
        self.strStandard          = std
        self.strSubject           = subject
        self.strActivity          = activity
        self.strExam              = exam
        self.strAddress1          = address1
        self.strAddress2          = address2
        self.strRegion            = region
        self.strCity              = city
        self.strState             = state
        self.strCountry           = country
        self.strZipCode           = zipCode
        self.strAvailability      = availability
        self.strDuration          = duration
        self.strHasInstiture      = hasInstitute
        self.strDescription       = description
        self.strEmail             = email
        self.strContactNo         = contactNo
        self.ratingUser           = ratingUser
        self.rating               = rating
    }
    
    init(name:String, rating:Double, comment:String, date:String) {
        
        self.strUserName    = name
        self.rating         = rating
        self.strComment     = comment
        self.strDate        = date
    }
    
    var strLocation:String {
        if(self.strAddress2.isEmptyStr){
            return "\(self.strAddress1), \(self.strRegion), \(self.strCity) ,\(self.strState) - \(self.strZipCode), \(self.strCountry)"
        }
        return "\(self.strAddress1) \(self.strAddress2), \(self.strRegion), \(self.strCity) ,\(self.strState) - \(self.strZipCode), \(self.strCountry)"
    }
    
    var strFullAddress:String {
        if(self.strAddress2.isEmptyStr){
            return "\(self.strAddress1)\n\(self.strRegion), \(self.strCity)\n\(self.strState) - \(self.strZipCode), \(self.strCountry)"
        }
        return "\(self.strAddress1)\n\(self.strAddress2)\n\(self.strRegion), \(self.strCity)\n\(self.strState) - \(self.strZipCode), \(self.strCountry)"
    }
    
    var strAreaLocation1:String {
        return "\(self.strAddress1),\(self.strAddress2),\(self.strRegion),\(self.strCity),\(self.strState),\(self.strZipCode), \(self.strCountry)"
    }
    
    var strAreaLocation2:String {
        return "\(self.strAddress1),\(self.strRegion),\(self.strCity),\(self.strState),\(self.strZipCode), \(self.strCountry)"
    }
    
    var strAreaLocation3:String {
        return "\(self.strRegion),\(self.strCity),\(self.strState),\(self.strZipCode), \(self.strCountry)"
    }
    
    var teachType:String{
        return strCoachType == "1" ? "Academic" : "Activity"
    }
}

class SCInquiryModel:NSObject, NSCoding {
    
    var strFirstName     :String = ""
    var strLastName      :String = ""
    var strEmail         :String = ""
    var strPassword      :String = ""
    var strPhone         :String = ""
    var strDescription   :String = ""
    var strBoard         :String = ""
    var strStandard      :String = ""
    var strSubject       :String = ""
    var strExam          :String = ""
    var strActivity      :String = ""
    var strDate          :String = ""
    
    class func inquiryValidation(_ mirrored_object:Mirror, _ errorType:[ErrorType]) -> (Bool,Int)
    {
        for (index, attr) in mirrored_object.children.enumerated() {
            let value: String? = attr.value as? String
            
            if((value?.isEmptyStr)!){
                if(!(index > 3)) {
                    showToast(errorType[index].rawValue)
                    return (false,index)
                }
            }else {
                switch(index)
                {
                case 2:
                    if(!(value?.isValidEmail())!){
                        showToast(ErrorType.inValidEmail.rawValue)
                        return (false,index)
                    }
                case 3:
                    if((value?.count)! < 4) {
                        showToast(ErrorType.inValidPassword.rawValue)
                        return (false,index)
                    }
                case 4:
                    if((value?.count)! < 10) {
                        showToast(ErrorType.inValidPhone.rawValue)
                        return (false,index)
                    }
                default:
                    break
                }
            }
        }
        return (true,0)
    }
    
    init(fname:String, lname:String, email:String, pwd:String, pno:String, des:String, board:String, std:String, subject:String, exam:String, activity:String, date:String) {
        
        self.strFirstName    = fname
        self.strLastName     = lname
        self.strEmail        = email
        self.strPassword     = pwd
        self.strPhone        = pno
        self.strDescription  = des
        self.strBoard        = board
        self.strStandard     = std
        self.strSubject      = subject
        self.strExam         = exam
        self.strActivity     = activity
        self.strDate         = date
    }
    
    init(fname:String, lname:String, email:String, pwd:String, pno:String) {
        
        self.strFirstName    = fname
        self.strLastName     = lname
        self.strEmail        = email
        self.strPassword     = pwd
        self.strPhone        = pno
    }
    
    required init(coder decoder: NSCoder) {
        self.strFirstName = decoder.decodeObject(forKey: "FirstName") as? String ?? ""
        self.strLastName = decoder.decodeObject(forKey: "LastName") as? String ?? ""
        self.strEmail = decoder.decodeObject(forKey: "EmailAddress") as? String ?? ""
        self.strPassword = decoder.decodeObject(forKey: "Password") as? String ?? ""
        self.strPhone = decoder.decodeObject(forKey: "PhoneNo") as? String ?? ""
    }
    
    func encode(with coder: NSCoder) {
        coder.encode(strFirstName, forKey: "FirstName")
        coder.encode(strLastName, forKey: "LastName")
        coder.encode(strEmail, forKey: "EmailAddress")
        coder.encode(strPassword, forKey: "Password")
        coder.encode(strPhone, forKey: "PhoneNo")
    }
}
