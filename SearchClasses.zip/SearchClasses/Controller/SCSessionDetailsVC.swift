//
//  SCSessionDetailsVC.swift
//  Search Classes
//
//  Created by ADMS on 23/04/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class SCSessionDetailsVC: CustomVC {
    
    @IBOutlet var bottomHeight:NSLayoutConstraint!
    @IBOutlet var tblCoachDetails:UITableView!
    @IBOutlet var viewBottom:UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.bottomHeight.constant = 0
        viewBottom.subviews.map{$0.isHidden = true}
        
        let params = ["Coach_ID" : strCoachID!]
        
        self.callGetCoachDetails(API.getCoachDetails, params) {
            self.bottomHeight.constant = 60
            self.viewBottom.subviews.map{$0.isHidden = false}
            self.callClassRatingApi()
        }
    }
    
    func callClassRatingApi()
    {
        self.callGetUserRating(["Coach_ID" : strCoachID!]) {
            self.tblCoachDetails.reloadData()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SCSessionDetailsVC
{
    @IBAction func btnInquiryAction(_ sender:UIButton)
    {
        add(asChildViewController: self.inquiryPopupVC, self)
    }
}

extension SCSessionDetailsVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrClassRating.count + (selectedCoachData != nil ? 2 : 0)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.row == 0 ? 200 : UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String = "SessionHeaderCell"
        if indexPath.row == 1 {
            strIdentifier = "SessionDetailCell"
        }else{
            if(indexPath.row == 2){
                strIdentifier = "SessionReviewHeaderCell"
            }else if(indexPath.row > 2){
                strIdentifier = "SessionReviewCell"
            }
        }
        
        let cell:TableCell = tableView.tableCellConfiguration(strIdentifier, indexPath)
        if(indexPath.row == 0)
        {
            (cell.contentView.subviews[0].subviews[0] as! UIImageView).image = UIImage.init(named: selectedCoachData.teachType)
        }
        else if indexPath.row == 1 {
            cell.delegate = self
            cell.displayCoachDetails(self.arrClassRating.count)
        }else {
            if(indexPath.row > 1){
                cell.displayClassRatingDetails(arrClassRating[indexPath.row-2])
            }
        }
        return cell
    }
}

extension SCSessionDetailsVC: TableCellDelegate
{
    func tappedOn_Mail_Location_Rate(_ tag: NSInteger, _ superViewTag: NSInteger) {
        
        if (tag == 9) {
            pushViewController(self, "SessionLocationVC", "Class Location")
        }else if (tag == 10) {
            let email = selectedCoachData.strEmail
            if let url = URL(string: "mailto:\(email)") {
                if #available(iOS 10.0, *) {
                    UIApplication.shared.open(url)
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        }else {
            strCoachID = selectedCoachData.strCoachID
            self.classRatingVC.delegate = self
            add(asChildViewController: self.classRatingVC, self)
        }
    }
}

extension SCSessionDetailsVC: ClassRatingDelegate
{
    func setRating(_ idx: NSInteger, _ rating: Double, _ comment:String)
    {
        let coachModel:CoachModel = selectedCoachData
        coachModel.rating = rating
        coachModel.strComment = comment
        selectedCoachData = coachModel
        self.callClassRatingApi()
    }
}

