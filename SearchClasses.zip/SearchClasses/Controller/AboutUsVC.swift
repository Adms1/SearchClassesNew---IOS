//
//  AboutUsVC.swift
//  Search Classes_New
//
//  Created by ADMS on 07/09/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var txtHeight:CGFloat = 0
class AboutUsVC: CustomVC {
    
    @IBOutlet var txtDescription:UITextView!
    @IBOutlet var txtDesHeight:NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(updateTextView(_:)), name: .descriptionHeightChange, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.hidesBackButton = true
        self.callGetAboutUs(completion: { (strDescription) in
            self.txtDescription.text = strDescription
            self.txtDescription.textColor = .black
            self.changeHeightOfTextView(self.txtDescription)
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AboutUsVC
{
    @IBAction func btnNextPreviousAction(_ sender:UIButton)
    {
        if(sender.tag == 1){
            guard txtDescription.text.removingWhitespaces() != "Description" else {
                showToast(ErrorType.description.rawValue)
                return
            }
            self.callAddAboutUs(txtDescription.text.removingWhitespaces())
        }else{
            self.navigationController?.pushPopTransition(self, false, false)
        }
    }
}

extension AboutUsVC
{
    @objc func updateTextView(_ notification:NSNotification)
    {
        let textView:UITextView = notification.userInfo!["TextView"] as! UITextView
        self.changeHeightOfTextView(textView)
    }
    
    func changeHeightOfTextView(_ textView:UITextView)
    {
        let fixedWidth: CGFloat = textView.frame.size.width
        let newSize: CGSize = textView.sizeThatFits(CGSize(width: fixedWidth, height:CGFloat.greatestFiniteMagnitude))
        
        txtHeight = newSize.height
        if(txtHeight < 200){
            self.txtDesHeight.constant = txtHeight
        }else {
            self.txtDesHeight.constant = 200
        }
    }
}
