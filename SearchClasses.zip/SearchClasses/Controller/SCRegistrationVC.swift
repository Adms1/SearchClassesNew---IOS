//
//  SCRegistrationVC.swift
//  Search Classes
//
//  Created by ADMS on 06/03/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class SCRegistrationVC: CustomVC {
    
    // MARK: - IBOutlet
    
    @IBOutlet var btnRegister:UIButton!
    @IBOutlet var btnViewTC:UIButton!
    @IBOutlet var selectionView:UIView!
    @IBOutlet var genderView:UIView!
    @IBOutlet var termsView:UIView!
    @IBOutlet var termsCheckBox:VKCheckbox!
    
    @IBOutlet var termsHeight:NSLayoutConstraint!
    @IBOutlet var emailHeight:NSLayoutConstraint!
    @IBOutlet var emailTop:NSLayoutConstraint!
    @IBOutlet var instituteHeight:NSLayoutConstraint!
    @IBOutlet var instituteTop:NSLayoutConstraint!
    @IBOutlet var headerTop:NSLayoutConstraint!
    
    var genderID:NSInteger = 1
    var hasInstitue:Bool = false
    var txtFld:UITextField!
    
    // MARK: -  Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(checkEmailExistOrNot(_:)), name: .existEmailCheck, object: nil)
        //NotificationCenter.default.addObserver(self, selector: #selector(chooseDateOfBirth(_:)), name: .openDatePicker, object: nil)
        
        self.setRadioButton()
        
        let attributedString = "View".makeBoldSubString("View", FontHelper.bold(size: 18), true, GetColor.headerColor, GetColor.headerColor)
        btnViewTC.setAttributedTitle(attributedString, for: .normal)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: .existEmailCheck, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        headerTop.constant = coachType == .myprofile ? -30 : 10
        selectionView.isHidden = coachType == .myprofile
        
        emailTop.constant = coachType == .myprofile ? 0 : 20
        emailHeight.constant = coachType == .myprofile ? self.view.frame.size.width - 20 : 0
        instituteTop.constant = 20
        instituteHeight.constant = 0
        termsHeight.constant = coachType == .myprofile ? termsView.frame.size.width : 0
        termsView.isHidden = coachType == .myprofile
        btnRegister.setTitle(coachType == .myprofile ? strUpdate : ViewControllerType.register.rawValue, for: .normal)
        
        if coachType == .myprofile {
            self.callGetCoachProfileDetailsApi(completion: { (registerModel, hasInstitue) in
                self.hasInstitue = hasInstitue
                self.genderID = Int(registerModel.strGenderID)!
                
                let array = [registerModel.strFirstName, registerModel.strLastName, registerModel.strInstitueName, registerModel.strEmailAddress, registerModel.strPassword, registerModel.strPhoneNumber, registerModel.strDateOfBirth]
                
                for (i,txt) in (self.view.subviews[3].subviews.flatMap{$0 as? UITextField}).enumerated() {
                    txt.text = array[i]
                }
                
                self.instituteTop.constant = self.hasInstitue ? 20 : 0
                self.instituteHeight.constant = self.hasInstitue ? 0 : self.view.frame.size.width - 20
                
                self.setRadioButton()
            })
        }
        
        for (i,txtfld) in (self.view.subviews[3].subviews.flatMap{$0 as? UITextField}).enumerated()
        {
            if(2 ~= i){
                txtfld.tag = coachType == .myprofile && !(self.hasInstitue) ? 0 : i+1
            }
            else if(3 ~= i){
                txtfld.tag = coachType == .myprofile ? 0 : i+1
            }
            else if(!(0...1 ~= i))
            {
                txtfld.tag = coachType == .myprofile ? self.hasInstitue ? i : i-1: i+1
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        (self.view.subviews[3].subviews.filter{$0 is UITextField} as! [UITextField]).forEach{$0.text = nil}
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SCRegistrationVC
{
    func setRadioButton()
    {
        let arrViews:[UIView] = [selectionView, genderView]
        for i in 0...1 {
            for view in arrViews {
                for subView in view.subviews[i].subviews {
                    if(subView.isKind(of: UIButton.classForCoder())) {
                        
                        let radioButton:UIButton = subView as! UIButton
                        radioButton.backgroundColor = UIColor.lightGray.withAlphaComponent(0.5)
                        
                        if(coachType == .myprofile) {
                            if(view == genderView && radioButton.tag == self.genderID) {
                                radioButton.backgroundColor = GetColor.radioColorRed
                            }else if(view == selectionView && radioButton.tag == (hasInstitue ? 2 : 1)) {
                                radioButton.backgroundColor = GetColor.radioColorRed
                            }
                        }
                        else if(radioButton.tag == 1){
                            radioButton.backgroundColor = GetColor.radioColorRed
                        }
                    }
                    let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                    subView.addGestureRecognizer(tapGesture)
                }
            }
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        let superView:UIView = (gesture.view?.superview?.superview)!
        for i in 0...1 {
            for view in superView.subviews[i].subviews.filter({($0.isKind(of: UIButton.classForCoder()))}) {
                
                let radioButton:UIButton = view as! UIButton
                radioButton.backgroundColor = UIColor.lightGray.withAlphaComponent(0.5)
            }
        }
        
        let id:NSInteger = (gesture.view?.tag)! > 2 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        let radioButton:UIButton = superView.subviews[id-1].subviews[0] as! UIButton
        radioButton.backgroundColor = GetColor.radioColorRed
        
        switch superView {
            //        case userView:
        //            self.hideShowViews(false, true, id == 2 ? false:true)
        case genderView:
            genderID = id
        default:
            hasInstitue = id == 2
        }
    }
    
    @objc func checkEmailExistOrNot(_ notification:NSNotification)
    {
        let txtEmail:UITextField = notification.userInfo!["TextField"] as! UITextField
        callEmailExistApi(txtEmail)
    }
}

extension SCRegistrationVC
{
    @IBAction func btnClickOnView(_ sender:UIButton)
    {
        if let url = URL(string: API.termsConditions) {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
    @IBAction func tappedOnTermsCondition(_ gesture:UIGestureRecognizer)
    {
        termsCheckBox.setOn(!termsCheckBox.isOn(), animated: true)
    }
    
    @objc func chooseDateOfBirth(_ notification:NSNotification)
    {
        txtFld = notification.userInfo!["DOB"] as! UITextField
        txtFld.text = txtFld.text == nil ? Date().toString(dateFormat: dateFormate) : txtFld.text
        
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = (txtFld.text?.toDate(dateFormat: dateFormate))!
        selector.optionCurrentDateRange.setStartDate((txtFld.text?.toDate(dateFormat: dateFormate))!)
        selector.optionCurrentDateRange.setEndDate((txtFld.text?.toDate(dateFormat: dateFormate))!)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
    
    @IBAction func btnAddRegisterAction(_ sender:UIButton)
    {
        let textFields:[UITextField] = self.view.subviews[3].subviews.filter{$0 is UITextField} as! [UITextField]
        textFields.forEach{$0.setUpBorder(.white)}
        
        let registerModel = SCRegisterModel.init(fname: textFields[0].text!, lname: textFields[1].text!, institueName: textFields[2].text!, eid: textFields[3].text!, pwd: textFields[4].text!, pno: textFields[5].text!, dob: Date().toString(dateFormat: "dd/MM/yyyy"), gid: "\(genderID)")
        
        let erroTypes:[ErrorType] = [.firstName, .lastName, .institue, .email, .password, .phoneNumber, .dateOfBirth, .gender]
        
        let result = SCRegisterModel.registerValidation(Mirror(reflecting: registerModel), erroTypes, hasInstitue)
        if result.0 {
            
            if(self.title == ViewControllerType.register.rawValue) {
                if(!(termsCheckBox.isOn())){
                    showToast(ErrorType.termsCondition.rawValue)
                    return
                }
            }
            
            var params = ["FirstName" : registerModel.strFirstName,
                          "LastName" : registerModel.strLastName,
                          "EmailAddress" : registerModel.strEmailAddress,
                          "Password" : registerModel.strPassword,
                          "PhoneNumber" : registerModel.strPhoneNumber,
                          "Gender_ID" : registerModel.strGenderID,
                          //                          "DateOfBirth" : registerModel.strDateOfBirth,
                "HasInstitute" : hasInstitue ? "true" : "false",
                "InstituteName" : registerModel.strInstitueName,
                "CreateDate" : registerModel.strDateOfBirth]
            
            if(coachType == .myprofile) {
                params["Coach_ID"] = coachID!
            }
            
            UserDefaults.standard.set(registerModel.strEmailAddress, forKey: "EmailID")
            UserDefaults.standard.set(registerModel.strFirstName, forKey: "UserName")
            UserDefaults.standard.set(registerModel.strPassword, forKey: "Password")
            
            callRegisterUpdateCoachApi(params)
        }
        else {
            textFields[result.1].showErrorView
        }
    }
}

// MARK: -  Calender Delegate

extension SCRegistrationVC:WWCalendarTimeSelectorProtocol
{
    func WWCalendarTimeSelectorShouldSelectDate(_ selector: WWCalendarTimeSelector, date: Date) -> Bool {
        if date.timeIntervalSinceNow.sign == .minus || date.toString(dateFormat: dateFormate) == Date().toString(dateFormat: dateFormate) {
            //myDate is earlier than Now (date and time)
            return true
        } else {
            //myDate is equal or after than Now (date and time)
            return false
        }
    }
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        
        dateFormatter.dateFormat = dateFormate
        txtFld.setUpBorder(.white)
        txtFld.text = date.toString(dateFormat: dateFormate)
    }
}

