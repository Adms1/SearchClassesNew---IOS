//
//  SCLoginVC.swift
//  Search Classes
//
//  Created by ADMS on 05/03/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
//import FBSDKLoginKit
//import GoogleSignIn

class SCLoginVC: CustomVC {
    
    @IBOutlet var socialView:UIView!
    @IBOutlet var btnHome:UIButton!
    @IBOutlet var btnRegister:UIButton!
    
    // MARK: Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.subviews[3].isHidden = bundleName.contains("Teacher")
        
        //        GIDSignIn.sharedInstance().clientID = Constants.clientID
        //        GIDSignIn.sharedInstance().delegate = self
        //        GIDSignIn.sharedInstance().uiDelegate = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(login), name: .login, object: nil)
        
        let attributedHString = self.title!.makeBoldSubString(self.title!, FontHelper.bold(size: 18), true, GetColor.headerColor, GetColor.headerColor)
        btnHome.setAttributedTitle(attributedHString, for: .normal)
        
        let attributedRString = "Don't have an account? Register".makeBoldSubString("Register", FontHelper.bold(size: 18), true, GetColor.headerColor, .gray)
        btnRegister.setAttributedTitle(attributedRString, for: .normal)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.addEffects()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        (self.view.subviews[2].subviews.filter{$0 is UITextField} as! [UITextField]).forEach{$0.text = nil}
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SCLoginVC
{
    func addEffects()
    {
        for i in 0...socialView.subviews.count-1 {
            for btn in socialView.subviews[i].subviews {
                addShadow(btn, 3.0, 0.3)
            }
        }
    }
    
    //    func loginWithFacebook()
    //    {
    //        let fbLoginManager = FBSDKLoginManager()
    //        fbLoginManager.logIn(withReadPermissions: ["public_profile", "email"], from: self) { (result, error) in
    //            if let error = error {
    //                print("Failed to login: \(error.localizedDescription)")
    //                return
    //            }
    //            else if (result?.isCancelled)! {
    //                return
    //            }
    //
    //            guard let accessToken = FBSDKAccessToken.current() else {
    //                print("Failed to get access token")
    //                return
    //            }
    //
    //            let req = FBSDKGraphRequest(graphPath: "me", parameters: ["fields":"first_name,last_name,email,gender,birthday"], tokenString: accessToken.tokenString, version: nil, httpMethod: "GET")
    //
    //            req?.start(completionHandler: { (connection, result, error) in
    //
    //                if(error == nil)
    //                {
    //                    //let credential = FacebookAuthProvider.credential(withAccessToken: accessToken.tokenString)
    //
    //                    //                    FirebaseFunctions.firebase_Facebook_Google_Auth(credential:credential, fdata: result as? [String : AnyObject], gdata:nil, completion: { (user) in
    //                    //
    //                    //                        if user != nil {
    //                    //                            userData = user
    //                    //                            self.pushToView()
    //                    //                        }
    //                    //                    })
    //                }
    //                else
    //                {
    //                    print("error \(error)")
    //                }
    //            })
    //        }
    //    }
    //
    //    func loginWithGooglePlus()
    //    {
    //        GIDSignIn.sharedInstance().signIn()
    //    }
    
    @objc func login()
    {
        let textFields:[UITextField] = self.view.subviews[2].subviews as! [UITextField]
        
        let loginModel = SCLoginModel.init(eid: textFields[0].text!, pwd: textFields[1].text!)
        let erroTypes:[ErrorType] = [.email, .password]
        
        let result = SCLoginModel.loginValidation(Mirror(reflecting: loginModel), erroTypes)
        if result.0 {
            coachType = .none
            callLogin(loginModel)
        }else {
            //textFields[result.1].showErrorView
        }
    }
    
    /*func checkForSession()
     {
     self.checkForAvailabilityOfSession(completion: { (isExist) in
     if(!isExist){
     
     self.callGetFamilyApi((["FamilyID" : familyID!], API.getFamilyList)) { (result) in
     arrFamilyData = result
     isUserFamily = strContactID == arrFamilyData[0].strContactID
     
     if(isUserFamily) {
     
     backFromLogin = true
     fromWhichApp = .classS
     addContactFromMenu = false
     
     pushViewController(self, ViewControllerType.familyList.rawValue, nil)
     }else{
     add(asChildViewController: self.confirmPopUpVC, self)
     }
     }
     
     }else{
     self.btnBackRootAction(nil)
     }
     })
     }*/
}

extension SCLoginVC
{
    @IBAction func btnSocialMediaAction(_ sender:UIButton)
    {
        //sender.tag == 1 ? self.loginWithFacebook() : self.loginWithGooglePlus()
    }
    
    @IBAction func btn_Login_Register_ForgotPassword_Action(_ sender:UIButton)
    {
        switch sender.tag {
        case 10:
            self.login()
        case 20:
            coachType = .register
            pushViewController(self, SCViewControllerType.scRegister.rawValue, ViewControllerType.register.rawValue)
        default:
            add(asChildViewController: self.forgotPasswordVC, self)
        }
    }
}

//extension SCLoginVC: GIDSignInDelegate, GIDSignInUIDelegate
//{
//    // MARK: Google SignIn Delegate
//    
//    func sign(_ signIn: GIDSignIn!, present viewController: UIViewController!) {
//        self.present(viewController, animated: true, completion: nil)
//    }
//    
//    func sign(_ signIn: GIDSignIn!, dismiss viewController: UIViewController!) {
//        self.dismiss(animated: true, completion: nil)
//    }
//    
//    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
//        
//        if let error = error {
//            // ...
//            return
//        }
//        
//        //guard let authentication = user.authentication else { return }
//        //let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken,accessToken: authentication.accessToken)
//        
//        //        let userId = user.userID
//        //        let idToken = user.authentication.idToken
//        //        let fullName = user.profile.name
//        //        let givenName = user.profile.givenName
//        //        let familyName = user.profile.familyName
//        //        let email = user.profile.email
//    }
//}

