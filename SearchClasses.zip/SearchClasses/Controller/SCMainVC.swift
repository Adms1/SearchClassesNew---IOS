//
//  SCMainVC.swift
//  Search Classes
//
//  Created by ADMS on 19/04/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import CoreLocation

class SCMainVC: CustomVC {
    
    @IBOutlet var btnLogin:UIButton!
    @IBOutlet var btnRegister:UIButton!
    @IBOutlet var lblLine:UILabel!
    
    var arraySearch:[String] = []
    var textFields:[DropDownTextField] = []
    
    let locationManager = CLLocationManager()
    let geocoder = CLGeocoder()
    var placemark: CLPlacemark?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(searchSession(_:)), name: .searchSession, object: nil)
        
        self.addAutoCompleteMenu()
        DispatchQueue.global(qos: .background).async {
            self.getValues()
        }
        
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.requestWhenInUseAuthorization()
        
        if (CLLocationManager.authorizationStatus() == CLAuthorizationStatus.denied)
        {
            print("DENIED")
            UIApplication.shared.openURL(URL.init(string: UIApplicationOpenSettingsURLString)!)
        }
        
        if (CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse ||
            CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways){
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.setLoginUser()
        self.navigationController?.isNavigationBarHidden = true
        
        textFields = self.view.subviews.filter{$0 is DropDownTextField} as! [DropDownTextField]
        textFields.forEach{$0.text = nil}
        
        if CLLocationManager.locationServicesEnabled() {
            self.locationManager.delegate = self
            self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            self.locationManager.startUpdatingLocation()
        }
    }
    
    override func logOut() {
        self.logOutAction { (i) in
            if(i == 1){
                self.setLoginUser()
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SCMainVC
{
    func resetData()
    {
        selectedGenderId = 0
        strSelectedInstitute = ""
        strSelectedSubjectName = ""
        strSelectedBoard = ""
        strSelectedStd = ""
        strSelectedActivity = ""
        strSelectedRegion = ""
        strSelectedExam = ""
        strSelectedTeacherName = ""
        arrRegionSearchData = []
        arrRegionData = []
    }
    
    func setLoginUser()
    {
        self.resetData()
        
        if(studentID != nil){
            let uName = userName?.components(separatedBy: " ").first
            let attributedString = "Hi \(uName!)".makeBoldSubString(uName!, FontHelper.bold(size: 18), true, GetColor.headerColor, GetColor.headerColor)
            
            btnLogin.setTitle(nil, for: .normal)
            btnLogin.setAttributedTitle(NSAttributedString.init(string: ""), for: .normal)
            btnRegister.setAttributedTitle(attributedString, for: .normal)
            lblLine.text = nil
        }
        else{
            let attributedLString = "Login".makeBoldSubString("Login", FontHelper.bold(size: 18), true, .gray, .gray)
            let attributedRString = "Register".makeBoldSubString("Register", FontHelper.bold(size: 18), true, GetColor.headerColor, GetColor.headerColor)
            
            btnLogin.setAttributedTitle(attributedLString, for: .normal)
            btnRegister.setAttributedTitle(attributedRString, for: .normal)
            lblLine.text = "|"
        }
    }
    
    // TODO: - AutoCompleteMenu
    
    func addAutoCompleteMenu()
    {
        for view in self.view.subviews.filter({($0.isKind(of: DropDownTextField.classForCoder()))}) {
            
            let dropDownTextField:DropDownTextField = view as! DropDownTextField
            activateField = dropDownTextField
            
            dropDownTextField.dropDownTableView.tag = 1
            dropDownTextField.dropDownTableView.dataSource = self
            dropDownTextField.dropDownTableView.delegate = self
            dropDownTextField.dropDownTableView.isHidden = true
            
            dropDownTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
            
            dropDownTextField.addTarget(self, action: #selector(textFieldDidBegin(_:)), for: .editingDidBegin)
        }
    }
    
    func getValues()
    {
        let text = try! String(contentsOfFile: Bundle.main.path(forResource: "world-cities", ofType: "txt")!) // Reading File
        let lineArray = text.components(separatedBy: "\n") // Separating Lines
        
        for eachLA in lineArray
        {
            let wordArray = eachLA.components(separatedBy: ",")
            if(wordArray.count == 4)
            {
                if(wordArray[1].caseInsensitiveCompare("india") == ComparisonResult.orderedSame)
                {
                    self.arrCityData.append(wordArray[0])
                }
            }
        }
        self.arrCityData = self.arrCityData.sorted(by: <)
    }
}

extension SCMainVC: CLLocationManagerDelegate
{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        guard strSelectedSessionLocation == nil else {
            self.textFields[1].text = strSelectedSessionLocation
            return
        }
        
        geocoder.reverseGeocodeLocation(locations.last!, completionHandler: { (placemarks, error) in
            if error == nil, let placemark = placemarks, !placemark.isEmpty {
                self.placemark = placemark.last
            }
            if let city = self.placemark?.locality, !city.isEmpty {
                strSelectedSessionLocation = city
                self.textFields[1].text = strSelectedSessionLocation
            }
        })
    }
}

extension SCMainVC: UITextFieldDelegate
{
    @objc func textFieldDidBegin(_ textField: DropDownTextField)
    {
        if activateField.dropDownTableView.isHidden == false {
            //activateField.dropDownTableView.hideShowTblView(false)
            activateField.dropDownTableView.isHidden = true
        }
        
        activateField = textField
        
        switch textField.placeholder! {
        case "Location":
            arraySearch = arrCityData
            
        default:
            break
        }
        
        switch textField.placeholder! {
        case "Location":
            arrCityData = arraySearch
            textField.dropDownTableView.setUpTblHeight(arraySearch)
            textField.dropDownTableView.isHidden = false
            
        default:
            break
        }
    }
    
    @objc func textFieldDidChange(_ textField: DropDownTextField) {
        
        var arrayFilter:[String] = []
        
        let filtered = arraySearch.filter { $0.range(of: textField.text!.removingWhitespaces(), options: .caseInsensitive) != nil }
        arrayFilter = textField.text == "" ? [] : filtered
        
        switch textField.placeholder! {
        case "Location":
            arrCityData = arrayFilter.map { $0 }
        default:
            break
        }
        
        if(arrayFilter.count == 0){
            //            textField.dropDownTableView.hideShowTblView(false)
            if textField.placeholder == "Location" {
                strSelectedSessionLocation = textField.text
            }
            textField.dropDownTableView.isHidden = true
            return
        }
        
        if textField.placeholder == "Location" {
            strSelectedSessionLocation = textField.text
            textField.dropDownTableView.setUpTblHeight(arrayFilter)
            textField.dropDownTableView.isHidden = false
        }else{
            textField.dropDownTableView.isHidden = true
        }
    }
}

extension SCMainVC
{
    @IBAction func btnLoginRegisterAction(_ sender:UIButton)
    {        
        guard (sender.attributedTitle(for: .normal)?.string.contains("Hi"))!  else {
            if(sender.tag == 1){
                coachType = .none
                pushViewController(self, ViewControllerType.login.rawValue, "Home")
            }else{
                coachType = .register
                pushViewController(self, SCViewControllerType.scRegister.rawValue, ViewControllerType.register.rawValue)
            }
            return
        }
        self.btnMenuOpenAction(sender)
    }
    
    @IBAction func btnSearchSessionAction(_ sender:UIButton)
    {
        strSelectedLesson = textFields[0].text!
        strSelectedSessionLocation = textFields[1].text
        strCoachType = "0"
        if activateField.dropDownTableView.isHidden == false {
            activateField.dropDownTableView.isHidden = true
        }
        
        guard !(strSelectedSessionLocation?.isEmptyStr)! else {
            if((strSelectedSubjectName?.isEmptyStr))! {
                showToast(ErrorType.selectLocation.rawValue)
            }
            return
        }
        
        if(sender.tag != 0){
            strCoachType = sender.tag == 1 ? "1,2" : "3"
        }
        pushViewController(self, "SessionListVC", strSelectedSubjectName)
    }
    
    @objc func searchSession(_ notification:NSNotification)
    {
        self.btnSearchSessionAction(self.view.subviews[4] as! UIButton)
    }
}

extension SCMainVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch activateField.placeholder! {
        case "Location":
            return arrCityData.count
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = activateField.dropDownTableView.dequeueReusableCell(withIdentifier: "Cell")
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "Cell")
            cell?.selectionStyle = .none
        }
        
        var array:[String] = []
        switch activateField.placeholder! {
        case "Location":
            array = arrCityData
        default:
            break
        }
        
        cell?.textLabel?.font = FontHelper.regular(size: DeviceType.isIpad ? 15 :12)
        cell!.textLabel!.attributedText = array[indexPath.row].makeBoldSubString(activateField.text!, FontHelper.bold(size: DeviceType.isIpad ? 15 :12), false, .black, .black)
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = activateField.dropDownTableView.cellForRow(at: indexPath)
        activateField.text = cell?.textLabel?.text
        
        if activateField.placeholder == "Location" && !(activateField.text?.isEmptyStr)! {
            strSelectedSessionLocation = activateField.text
        }
        self.dismissPicker()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if activateField.dropDownTableView.isHidden == false {
            activateField.dropDownTableView.isHidden = true
        }
    }
}
