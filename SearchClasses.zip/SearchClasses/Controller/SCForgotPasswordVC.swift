//
//  SCForgotPasswordVC.swift
//  Search Classes
//
//  Created by ADMS on 12/04/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class SCForgotPasswordVC: CustomVC {
    
    var mainView:UIView!
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        self.addEffects()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.reset
    }
    
    var reset:Void
    {
        for txtFld in (mainView.subviews.flatMap{$0 as? InputTextField}){
            txtFld.text = nil
            txtFld.setUpBorder(.darkGray)
        }
    }
    
    @objc func addEffects()
    {
        mainView = self.addPopUpEffect        
        
        // 0
        let lblHeader:UILabel = self.mainView.subviews[0] as! UILabel
        lblHeader.layer.addBorder(edge: .bottom, color: .groupTableViewBackground, thickness: 1.0)
        lblHeader.text = self.title?.uppercased()
        
        // 1
        let txtfld:InputTextField = self.mainView.subviews[1] as! InputTextField
        txtfld.isSecureTextEntry = self.title == strChangePwd ? true : false
        txtfld.attributedPlaceholder = NSAttributedString(string: self.title == strChangePwd ? strCurrentPwd : strEmailId, attributes:[NSAttributedStringKey.foregroundColor: UIColor.darkGray, NSAttributedStringKey.font: txtfld.font!])
        txtfld.returnKeyType = txtfld.isSecureTextEntry ? .next : .done
        txtfld.rightImage = UIImage.init(named: txtfld.isSecureTextEntry ? "Password" : "Email")
        
        let aspectRatioConstraint1 = NSLayoutConstraint.init(item: txtfld, attribute: .width, relatedBy: .equal, toItem: txtfld, attribute: .height, multiplier: UIDevice.current.orientation == UIDeviceOrientation.portrait ? 344/45 : 74/5, constant: 0)
        txtfld.removeConstraint((txtfld.constraints.last)!)
        txtfld.addConstraint(aspectRatioConstraint1)
        
        // 2
        let txtfld_Npwd:InputTextField = self.mainView.subviews[2] as! InputTextField
        txtfld_Npwd.tag = self.title == strChangePwd ? txtfld.tag + 1 : 0
        let aspectRatioConstraint2 = NSLayoutConstraint.init(item: txtfld_Npwd, attribute: .width, relatedBy: .equal, toItem: txtfld_Npwd, attribute: .height, multiplier: UIDevice.current.orientation == UIDeviceOrientation.portrait ? 344/45 : 74/5, constant: self.title == strChangePwd ? 0 : txtfld_Npwd.frame.size.width)
        txtfld_Npwd.removeConstraint((txtfld_Npwd.constraints.last)!)
        txtfld_Npwd.addConstraint(aspectRatioConstraint2)
        txtfld_Npwd.rightImage = #imageLiteral(resourceName: "NewPassword")
        
        // 3
        let txtfld_Cpwd:InputTextField = self.mainView.subviews[3] as! InputTextField
        txtfld_Cpwd.tag = self.title == strChangePwd ? txtfld_Npwd.tag + 1 : 0
        txtfld_Cpwd.rightImage = #imageLiteral(resourceName: "NewPassword")
        
        // 4
        let btnBottom:UIButton = self.mainView.subviews[4] as! UIButton
        let title:String = self.title! == strChangePwd ? self.title! : strResetPwd
        btnBottom.setTitle(title.uppercased(), for: .normal)
    }
    
    func forgotPassword()
    {
        let txtEmail:UITextField = mainView.subviews[1] as! UITextField
        
        if ForgotPasswordModel.forgotPasswordValidation(txtEmail.text!, .email)
        {            
            callForgotPasswordApi(txtEmail)
        }
        else {
            txtEmail.showErrorView
        }
    }
    
    @IBAction func btnAction(_ sender:UIButton)
    {
        switch (sender.title(for: .normal)?.capitalized)! {
        case strResetPwd:
            self.forgotPassword()
        default:
            //mainView.scaleAnimation(fromValue: 1.0, toValue: 0.001, completion: {
            self.reset
            self.removePopup(nil)
            //})
        }
    }
}
