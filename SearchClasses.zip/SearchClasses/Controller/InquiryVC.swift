//
//  MySessionListVC.swift
//  Search Classes
//
//  Created by ADMS on 02/05/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class InquiryVC: CustomVC {
    
    @IBOutlet var tblInquiry:UITableView!
    var selectedSection:NSInteger = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblInquiry.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        callGetInquiry {
            self.lblNoRecord.isHidden = self.arrInquiryList.count > 0
            self.tblInquiry.reloadData()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension InquiryVC: UITableViewDataSource, UITableViewDelegate
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrInquiryList.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1//return arrInquiryList.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == selectedSection ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell:TableCell = tableView.dequeueReusableCell(withIdentifier: "InquiryHeaderCell") as! TableCell
        cell.displayInquiryHeaderDetails(arrInquiryList[section])
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        cell.contentView.tag = section
        cell.contentView.addGestureRecognizer(tapGesture)
        
        return arrInquiryList.count > 0 ? cell.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:TableCell = tableView.tableCellConfiguration("InquiryCell", indexPath)
        cell.delegate = self
        cell.contentView.tag = indexPath.section
        cell.displayInquiryDetails(arrInquiryList[indexPath.section])
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedSection == Index) {
            selectedSection = -1
        }
        else {
            selectedSection = Index
        }
        
        tblInquiry.reloadSections(IndexSet(integersIn: 0...arrInquiryList.count - 1) as IndexSet, with: .automatic)
        
        if(selectedSection != -1){
            tblInquiry.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedSection) as IndexPath, at: .none, animated: true)
        }
    }
}

extension InquiryVC: TableCellDelegate
{
    func tappedOn_Mail_Location_Rate(_ tag: NSInteger, _ superViewTag: NSInteger) {
        
        let email = arrInquiryList[superViewTag].strEmail
        if let url = URL(string: "mailto:\(email)") {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
}
