//
//  ViewController.swift
//  Search Classes
//
//  Created by ADMS on 05/03/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var strSelectedSubjectName:String?
var strSelectedInstitute:String = ""
var strSelectedActivity:String = ""
var strSelectedExam:String = ""
var selectedCoachData:CoachModel!
var strCoachID:String!
var strSelectedRegion:String?
var strSelectedLesson:String = ""
var strSelectedBoard:String = ""
var strSelectedStd:String = ""
var selectedGenderId:Int = 0
var strSelectedTeacherName:String?
var strSelectedSessionLocation:String?

var filterType:FilterType = .none

class SCSessionListVC: CustomVC {
    
    @IBOutlet var tblCoachList:UITableView!
    
    @IBOutlet var lblResultCount:UILabel!
    @IBOutlet var lblBoard:UILabel!
    @IBOutlet var lblStd:UILabel!
    @IBOutlet var lblStream:UILabel!
    
    @IBOutlet var tokenInputView:SVContactBubbleView!
    @IBOutlet var tokenHeightConstraint: NSLayoutConstraint?
    @IBOutlet var topConstrain: NSLayoutConstraint!
    @IBOutlet var locationView: UIView!
    @IBOutlet var locationViewHeightConstrain: NSLayoutConstraint!
    
    var arrCoachFilterDetails = [CoachModel]()
    var arrCoachTempValues = [CoachModel]()
    
    var dropTableView: UITableView!
    var arrFilterRegion:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for view in (self.view.subviews.flatMap{$0 as? TabBarView}){
            view.delegate = self
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.setupHeaderView()
        
        //--1
        let arrViews     = [lblBoard, lblStd, lblStream]
        let arrValues    = [strSelectedBoard, strSelectedStd, strSelectedActivity]
        
        for (i,lbl) in arrViews.enumerated() {
            let idx = lbl?.superview?.subviews.index(of: lbl!)
            lbl?.superview?.subviews[idx!+1].isHidden = true
            lbl?.text = " "
            
            switch filterType {
            case .all:
                lbl?.superview?.subviews[idx!+1].isHidden = false
                lbl?.text = arrValues[i]
                
            case .any:
                if(!(arrValues[i].isEmptyStr)){
                    lbl?.superview?.subviews[idx!+1].isHidden = false
                    lbl?.text = arrValues[i]
                }
            default:
                break
            }
        }
        self.getCoachList()
    }
    
    func getCoachList()
    {
        //--2
        
        let params = ["SubjectName" : strSelectedSubjectName!,
                      "TeacherName" : strSelectedTeacherName!,
                      "AddressCity" : strSelectedSessionLocation!,
                      "Institute" : strSelectedInstitute,
                      "BoardName" : strSelectedBoard,
                      "StandardName" : strSelectedStd,
                      "Gender_ID" : selectedGenderId == 0 ? "" : "\(selectedGenderId)",
            "Teach_Type" : strCoachType == "0" ? "" : "\(strCoachType!)",
            "RegionName" : strSelectedRegion == nil ? "" :strSelectedRegion!,
            "ActivityName" : strSelectedActivity,
            "EntranceTestName" : strSelectedExam]
        
        self.callGetCoachDetails(API.searchCoachCriteria, params) {
            
            self.arrCoachDetails = arrCoachList.map{ $0 }
            arrRegionData = self.arrCoachDetails.map{ $0.strRegion }.removeDuplicates(false)
            self.arrCoachFilterDetails = self.arrCoachDetails.map{ $0 }
            self.arrCoachTempValues = self.arrCoachDetails.map{ $0 }
            if(self.arrCoachDetails.count == 0){
                showToast(MessageType.noSession.rawValue)
            }
            if(strSelectedRegion != ""){
                arrRegionSearchData.append(strSelectedRegion!)
            }
            guard arrRegionSearchData.count == 0 else {
                self.tokenInputView.reloadData()
                self.addRegionWiseSession()
                return
            }
            self.tblCoachList.reloadData()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SCSessionListVC
{
    @IBAction func btnInquiryAction(_ sender:UIButton)
    {
        strCoachID = arrCoachDetails[sender.tag].strCoachID
        selectedCoachData = arrCoachDetails[sender.tag]
        add(asChildViewController: self.inquiryPopupVC, self)
    }
    
    @IBAction func btnViewDetailsAction(_ sender:UIButton)
    {
        strCoachID = arrCoachDetails[sender.tag].strCoachID
        selectedCoachData = nil
        pushViewController(self, "SessionDetailsVC", "Coach Details")
    }
}

extension SCSessionListVC: TabBarDelegate
{
    func tappedOnTabBar(_ tag: NSInteger, _ tabType: String)
    {
        viewTag = tag
        if(viewTag == 20){
            if(arrRegionData.count == 0 && arrRegionSearchData.count == 0){
                showToast(MessageType.noFilterOption.rawValue)
                return
            }
        }else if(viewTag == 30){
            if(arrCoachFilterDetails.count == 0) {
                showToast(MessageType.noFilterOption.rawValue)
                return
            }
        }else{
            self.navigationController?.pushPopTransition(self, false, false)
            return
        }
        strPopupTitle = tabType.components(separatedBy: "-").last!
        self.scPopUpVC.delegate = self
        add(asChildViewController: self.scPopUpVC, self)
    }
}

extension SCSessionListVC: SCPopupVCDelegate
{
    func filterSessionBasedOnLocation()
    {
        if(strSelectedRegion != "" && arrRegionSearchData.count == 0)
        {
            self.tokenInputView.reloadData()
            strSelectedRegion = ""
            self.getCoachList()
            return
        }
        
        self.arrCoachDetails = arrRegionSearchData.count > 0 ? [] : self.arrCoachFilterDetails
        for strRegion in arrRegionSearchData {
            let results = self.arrCoachFilterDetails.filter{$0.strRegion.caseInsensitiveCompare(strRegion) == .orderedSame}
            self.arrCoachDetails += results
        }
        self.tokenInputView.reloadData()
        self.filterSessionBasedOnBottomMenu()
    }
    
    func filterSessionBasedOnBottomMenu()
    {
        if(arrRegionSearchData.count > 0){
            arrCoachTempValues = arrCoachDetails
        }else{
            arrCoachTempValues = arrCoachFilterDetails
        }
        
        if(ratingSortType != .none){ // Filter By Rating (lower & upper)
            arrCoachDetails = arrCoachTempValues.sorted(by: { ratingSortType == .high ? $0.rating > $1.rating : $0.rating < $1.rating})
        }
        
        if(locationSortType != .none){ // Filter By Rating (lower & upper)
            arrCoachDetails = arrCoachTempValues.sorted(by: { locationSortType == .high ? $0.strRegion > $1.strRegion : $0.strRegion < $1.strRegion})
        }
        self.tblCoachList.reloadData()
    }
}

extension SCSessionListVC
{
    // TODO: - HeaderView
    
    func setupHeaderView()
    {
        let headerView:UIView = self.view.subviews[1]
        
        headerView.subviews[1].isHidden = studentID == nil
        
        let lblSessionName:UILabel = headerView.subviews[3] as! UILabel
        lblSessionName.text = strSelectedSubjectName == "" ? "ALL CLASSES" : strSelectedSubjectName
        
        let lblLocation:UILabel = headerView.subviews[4] as! UILabel
        lblLocation.text = strSelectedSessionLocation == nil ? "" : strSelectedSessionLocation!
        
        //        dropTableView = addCustomTableView(self, tokenInputView, self.view, .bottom)
        //        dropTableView.isHidden = true
        //        dropTableView.tag = 1
        
        tokenInputView.dataSource = self
        tokenInputView.delegate = self
        
        tokenInputView.reloadData()
    }
    
    func getRegion(_ region:String)
    {
        if arrRegionSearchData.contains(region) {
            if let idx = arrRegionSearchData.index(of: region) {
                arrRegionSearchData.remove(at: idx)
                self.tokenInputView.reloadData()
            }
        }else{
            let filteredArray = arrRegionData.filter { $0.localizedCaseInsensitiveContains(region) }
            if(filteredArray.count > 0){
                arrRegionSearchData.append(filteredArray[0])
                self.tokenInputView.textfield.text = nil
                self.tokenInputView.reloadData()
            }
        }
        
        arrFilterRegion = arrRegionData
        //        dropTableView.reloadData()
        //        dropTableView.setUpTblHeight(arrFilterRegion)
        //        dropTableView.isHidden = true
        self.view.endEditing(true)
        self.addRegionWiseSession()
    }
    
    func addRegionWiseSession()
    {
        self.arrCoachDetails = arrRegionSearchData.count > 0 ? [] : self.arrCoachFilterDetails
        for strRegion in arrRegionSearchData {
            print(self.arrCoachFilterDetails.map{$0.strRegion})
            let results = self.arrCoachFilterDetails.filter{$0.strRegion.caseInsensitiveCompare(strRegion) == .orderedSame}
            self.arrCoachDetails += results
        }
        self.filterSessionBasedOnBottomMenu()
        self.tblCoachList.reloadData()
    }
}

// MARK: SVContactBubbleDataSource

extension SCSessionListVC: SVContactBubbleDataSource
{
    func insetsForContactBubbleView(_ contactBubbleView: SVContactBubbleView) -> UIEdgeInsets?
    {
        return UIEdgeInsetsMake(5, 5, 5, 5)
    }
    
    func placeholderTextForContactBubbleView(_ contactBubbleView: SVContactBubbleView) -> String?
    {
        if arrRegionSearchData.count == 0 {
            return "Location Preferences"
        }
        return nil
    }
    
    func numberOfContactBubbleForContactBubbleView(_ contactBubbleView: SVContactBubbleView) -> Int
    {
        return arrRegionSearchData.count
    }
    
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, viewForContactBubbleAtIndex index: Int) -> UIView?
    {
        let region = arrRegionSearchData[index]
        let contactBubble = SVContactBubble.contactBubbleView(region, image: nil)
        contactBubble?.layoutIfNeeded()
        return contactBubble
    }
}

//MARK: SVContactBubbleDelegate

extension SCSessionListVC: SVContactBubbleDelegate
{
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, didDeleteBubbleWithTitle title: String)
    {
        arrFilterRegion = arrRegionData.filter { $0.range(of: title, options: .caseInsensitive) != nil }
        
        if let found = arrFilterRegion.first
        {
            if let index = arrRegionSearchData.index(where: {$0.caseInsensitiveCompare(found) == .orderedSame}) {
                arrRegionSearchData.remove(at: index)
                contactBubbleView.reloadData()
                arrFilterRegion = arrRegionData
                //dropTableView.reloadData()
                self.addRegionWiseSession()
            }
        }
    }
    
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, shouldBeginEditing text: String)
    {
        arrFilterRegion = arrRegionData
        //dropTableView.isHidden = false
        //dropTableView.setUpTblHeight(arrFilterRegion)
    }
    
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, didChangeText text: String)
    {
        if text == "" {
            arrFilterRegion = arrRegionData
        }
        else {
            arrFilterRegion = arrRegionData.filter { $0.range(of: text, options: .caseInsensitive) != nil }
        }
        //dropTableView.setUpTblHeight(arrFilterRegion)
        self.addRegionWiseSession()
    }
    
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, didFinishBubbleWithText text: String)
    {
        self.getRegion(text)
    }
    
    func contactBubbleView(_ contactBubbleView: SVContactBubbleView, contentSizeChanged size: CGSize)
    {
        self.tokenHeightConstraint?.constant = max(25,min(size.height, 150))
        self.locationView.subviews.forEach{$0.isHidden = arrRegionSearchData.count == 0}
        locationViewHeightConstrain.constant = arrRegionSearchData.count == 0 ? 0 : (self.tokenHeightConstraint?.constant)! + 25
        UIView.animate(withDuration: 0.5, animations: {
            self.view.layoutIfNeeded()
        })
    }
}

extension SCSessionListVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(tableView.tag == 1) {
            return arrFilterRegion.count
        }
        return arrCoachDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if(tableView.tag == 1)
        {
            var cell = self.dropTableView.dequeueReusableCell(withIdentifier: "Cell")
            if cell == nil {
                cell = UITableViewCell(style: .default, reuseIdentifier: "Cell")
                cell?.selectionStyle = .none
            }
            
            let region = arrFilterRegion[indexPath.row]
            let isarrSelectedRegions = arrRegionSearchData.contains(region)
            cell?.accessoryType = isarrSelectedRegions ? .checkmark : .none
            
            cell?.textLabel?.font = FontHelper.regular(size: DeviceType.isIpad ? 15 :12)
            cell!.textLabel!.attributedText = region.makeBoldSubString(self.tokenInputView.textfield.text, FontHelper.bold(size: DeviceType.isIpad ? 15 :12), false, .black, .black)
            
            return cell!
        }
        else
        {
            let cell:TableCell = tableView.tableCellConfiguration("SessionCell", indexPath)
            cell.contentView.subviews[0].subviews[2].tag = indexPath.row
            
            //--- View Details
            let arrBtns = cell.contentView.subviews[0].subviews.filter{$0 is UIButton}
            let btnVDIdx:NSInteger = cell.contentView.subviews[0].subviews.index(of: arrBtns[0])!
            cell.contentView.subviews[0].subviews[btnVDIdx].tag = indexPath.row
            
            //--- Inquiry
            let btnIIdx:NSInteger = cell.contentView.subviews[0].subviews.index(of: arrBtns[1])!
            cell.contentView.subviews[0].subviews[btnIIdx].tag = indexPath.row
            
            //--- Rating View
            let ratingView = cell.contentView.subviews[0].subviews.filter{$0 is FloatRatingView}
            let rateIdx:NSInteger = cell.contentView.subviews[0].subviews.index(of: ratingView[0])!
            cell.contentView.subviews[0].subviews[rateIdx].tag = indexPath.row
            
            cell.displayCoachListData(arrCoachDetails[indexPath.row])
            lblResultCount.text = "\(arrCoachDetails.count)"
            
            cell.delegate = self
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //self.segue("Session")
        if(tableView.tag == 1)
        {
            tableView.deselectRow(at: indexPath, animated: true)
            self.getRegion(arrFilterRegion[indexPath.row])
        }
        else
        {
            //            strSessionID = arrSessionDetails[indexPath.row].strSessionID
            //            isFromMySessionList = false
            //            selectedSessionModel = nil
            //            pushViewController(self, "SessionDetailsVC", "Class Details")
        }
    }
}

extension SCSessionListVC: TableCellDelegate
{
    func tappedOn_Session_Location_Rate(_ tag: NSInteger, _ strType:String)
    {
        index = tag
        selectedCoachData = arrCoachDetails[index]
        switch strType {
        case "Location":
            pushViewController(self, "SessionLocationVC", "Class Location")
        default:
            strCoachID = selectedCoachData.strCoachID
            self.classRatingVC.delegate = self
            add(asChildViewController: self.classRatingVC, self)
        }
    }
}

extension SCSessionListVC: ClassRatingDelegate
{
    func setRating(_ idx: NSInteger, _ rating: Double, _ comment:String)
    {
        let coachModel:CoachModel = selectedCoachData
        coachModel.rating = rating
        coachModel.strComment = comment
        arrCoachDetails[idx] = coachModel
        
        self.tblCoachList.reloadRows(at: [IndexPath.init(row: idx, section: 0)], with: .none)
    }
}
