//
//  SCClassSearchVC.swift
//  Search Classes
//
//  Created by ADMS on 06/03/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var strCoachType:String!
class SCClassSearchVC: CustomVC {
    
    var textFields:[UITextField] = []
    var arraySearch:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addAutoCompleteMenu()
        
        DispatchQueue.global(qos: .background).async {
            self.getValues()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        (self.view.subviews[0] as! UIImageView).image = UIImage.init(named: "bg_\(strCoachType == "0" ? "1" : strCoachType!)")
        textFields = self.view.subviews[2].subviews.filter{$0 is UITextField} as! [UITextField]
        
        selectType = .region
        self.callGetValuesApi {
            arrRegionSearchData = self.dicValues.values.sorted(by: <)
            
            self.callAutoCompleteData {
                self.filterData()
            }
        }
        
        let arrayValues = [strSelectedSessionLocation, strSelectedRegion, strSelectedInstitute, strSelectedTeacherName, strSelectedBoard, strSelectedStd, strSelectedLesson, strSelectedExam, strSelectedActivity]
        
        for (i,txtFld) in textFields.enumerated() {
            txtFld.text = arrayValues[i]
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        arrRegionSearchData = []
        arrRegionData = []
        arrCitySearchData = []
        arrCityData = []
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SCClassSearchVC
{
    func getValues()
    {
        let text = try! String(contentsOfFile: Bundle.main.path(forResource: "world-cities", ofType: "txt")!) // Reading File
        let lineArray = text.components(separatedBy: "\n") // Separating Lines
        
        for eachLA in lineArray
        {
            let wordArray = eachLA.components(separatedBy: ",")
            if(wordArray.count == 4)
            {
                if(wordArray[1].caseInsensitiveCompare("india") == ComparisonResult.orderedSame)
                {
                    self.arrCitySearchData.append(wordArray[0])
                }
            }
        }
        self.arrCitySearchData = self.arrCitySearchData.sorted(by: <)
    }
    
    func filterData()
    {
        arrBoardSearchData =  (arrCoachAutoCompleteList.first?.strBoard.isEmptyStr)! ? [] : (arrCoachAutoCompleteList.first?.strBoard.components(separatedBy: ","))!
        arrStdSearchData =  (arrCoachAutoCompleteList.first?.strStandard.isEmptyStr)! ? [] : (arrCoachAutoCompleteList.first?.strStandard.components(separatedBy: ","))!
        arrLessonSearchData =  (arrCoachAutoCompleteList.first?.strSubject.isEmptyStr)! ? [] : (arrCoachAutoCompleteList.first?.strSubject.components(separatedBy: ","))!
        arrExamSearchData =  (arrCoachAutoCompleteList.first?.strExam.isEmptyStr)! ? [] : (arrCoachAutoCompleteList.first?.strExam.components(separatedBy: ","))!
        arrActivitySearchData =  (arrCoachAutoCompleteList.first?.strActivity.isEmptyStr)! ? [] : (arrCoachAutoCompleteList.first?.strActivity.components(separatedBy: ","))!
    }
    
    // TODO: - AutoCompleteMenu
    
    func addAutoCompleteMenu()
    {
        for view in self.view.subviews[2].subviews.filter({($0.isKind(of: DropDownTextField.classForCoder()))}) {
            
            let dropDownTextField:DropDownTextField = view as! DropDownTextField
            activateField = dropDownTextField
            
            dropDownTextField.dropDownTableView.tag = 1
            dropDownTextField.dropDownTableView.dataSource = self
            dropDownTextField.dropDownTableView.delegate = self
            dropDownTextField.dropDownTableView.isHidden = true
            
            dropDownTextField.addTarget(self, action: #selector(textFieldDidBegin(_:)), for: .editingDidBegin)
            
            dropDownTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        }
    }
}

extension SCClassSearchVC
{
    @IBAction func btnSearchSessionAction(_ sender:UIButton)
    {
        self.dismissPicker()
        
        guard !(strSelectedSessionLocation?.isEmptyStr)! else {
            showToast(ErrorType.selectCity.rawValue)
            return
        }
        
        let result = textFields[1...5].filter{$0.text != ""}
        filterType = result.count == 4 ? .all : .any
        
        pushViewController(self, "SessionListVC", strSelectedLesson)
    }
}

extension SCClassSearchVC: UITextFieldDelegate
{
    @objc func textFieldDidBegin(_ textField: DropDownTextField)
    {
        if activateField.dropDownTableView.isHidden == false {
            activateField.dropDownTableView.isHidden = true
        }
        activateField = textField
        
        switch textField.placeholder! {
        case "Board":
            arraySearch = arrBoardSearchData.map { $0 }
        case "Standard":
            arraySearch = arrStdSearchData.map { $0 }
        case "Subject":
            arraySearch = arrLessonSearchData.map { $0 }
        case "Entrance Test":
            arraySearch = arrExamSearchData.map { $0 }
        case "Activity":
            arraySearch = arrActivitySearchData.map { $0 }
        case "City":
            arraySearch = arrCitySearchData.map { $0 }
        case "Location":
            arraySearch = arrRegionSearchData.map { $0 }
        default:
            break
        }
        
        guard arraySearch.count > 0 else{
            return
        }
        //        textField.dropDownTableView.setUpTblHeight(arraySearch)
        //        textField.dropDownTableView.isHidden = false
    }
    
    @objc func textFieldDidChange(_ textField: DropDownTextField) {
        
        var array:[String] = []
        
        let filtered = arraySearch.filter { $0.range(of: textField.text!, options: .caseInsensitive) != nil }
        array = textField.text == "" ? [] : filtered
        
        switch textField.placeholder! {
        case "Board":
            arrBoardData = array.map { $0 }
            strSelectedBoard = textField.text != "" ? textField.text! : ""
        case "Standard":
            arrStdData = array.map { $0 }
            strSelectedStd = textField.text != "" ? textField.text! : ""
        case "Subject":
            arrLessonData = array.map { $0 }
            strSelectedLesson = textField.text != "" ? textField.text! : ""
        case "Entrance Test":
            arrExamData = array.map { $0 }
            strSelectedExam = textField.text != "" ? textField.text! : ""
        case "City":
            arrCityData = array.map { $0 }
            strSelectedSessionLocation = textField.text != "" ? textField.text! : ""
        case "Location":
            arrRegionData = array.map { $0 }
            strSelectedRegion = textField.text != "" ? textField.text! : ""
        case "Activity":
            arrActivityData = array.map { $0 }
            strSelectedActivity = textField.text != "" ? textField.text! : ""
        default:
            break
        }
        
        if(array.count == 0){
            textField.dropDownTableView.isHidden = true
            return
        }
        
        textField.dropDownTableView.setUpTblHeight(filtered)
        textField.dropDownTableView.isHidden = false
    }
}

extension SCClassSearchVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch activateField.placeholder! {
        case "Board":
            return arrBoardData.count
        case "Standard":
            return arrStdData.count
        case "Subject":
            return arrLessonData.count
        case "Entrance Test":
            return arrExamData.count
        case "City":
            return arrCityData.count
        case "Location":
            return arrRegionData.count
        case "Activity":
            return arrActivityData.count
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = activateField.dropDownTableView.dequeueReusableCell(withIdentifier: "Cell")
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "Cell")
            cell?.selectionStyle = .none
        }
        
        var array:[String] = []
        switch activateField.placeholder! {
        case "Board":
            array = arrBoardData
        case "Standard":
            array = arrStdData
        case "Subject":
            array = arrLessonData
        case "Entrance Test":
            array = arrExamData
        case "City":
            array = arrCityData
        case "Location":
            array = arrRegionData
        case "Activity":
            array = arrActivityData
        default:
            break
        }
        
        cell?.textLabel?.font = FontHelper.regular(size: DeviceType.isIpad ? 15 :12)
        if(array.count > 0) {
            cell!.textLabel!.text = array[indexPath.row]
            cell!.textLabel!.attributedText = array[indexPath.row].makeBoldSubString(activateField.text!, FontHelper.bold(size: DeviceType.isIpad ? 15 :12), false, .black, .black)
        }
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = activateField.dropDownTableView.cellForRow(at: indexPath)
        activateField.text = cell?.textLabel?.text
        
        switch activateField.placeholder! {
        case "City":
            strSelectedSessionLocation = activateField.text
        case "Subject":
            strSelectedLesson = activateField.text!
        case "Board":
            strSelectedBoard = activateField.text!
        case "Standard":
            strSelectedStd = activateField.text!
        case "Subject":
            strSelectedLesson = activateField.text!
        case "Location":
            strSelectedRegion = activateField.text!
        case "Entrance Test":
            strSelectedExam = activateField.text!
        case "Activity":
            strSelectedActivity = activateField.text!
        default:
            break
        }
        self.dismissPicker()
    }
}

