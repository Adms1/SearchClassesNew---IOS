//
//  SessionLocationVC.swift
//  Search Classes
//
//  Created by ADMS on 17/04/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class SCSessionLocationVC: CustomVC {
    
    @IBOutlet var sessionMapView:MKMapView!
    var polygon: MKPolygon? = nil
    var coordinate = CLLocationCoordinate2D()
    var lcount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        lcount = 0
        self.getLocationFromAddress(address: selectedCoachData.strAreaLocation1)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SCSessionLocationVC
{
    func getLocationFromAddress(address : String)  {
        let geocoder = CLGeocoder()
        var coordinates = CLLocationCoordinate2D()
        geocoder.geocodeAddressString(address, completionHandler: {(placemarks, error) -> Void in
            if((error) != nil){
                print("Error", error!)
                self.lcount += 1
                if(self.lcount == 1){
                    self.getLocationFromAddress(address: selectedCoachData.strAreaLocation2)
                }else if(self.lcount == 2){
                    self.getLocationFromAddress(address: selectedCoachData.strAreaLocation3)
                }else{
                    showToast("No location found")
                }
            }
            
            if let placemark = placemarks?.first {
                coordinates = placemark.location!.coordinate
                let annotation = MKPointAnnotation()
                annotation.title = selectedCoachData.strCoachName
                annotation.subtitle = selectedCoachData.strLocation
                annotation.coordinate = coordinates
                self.sessionMapView.addAnnotation(annotation)
                self.zoomMapaFitAnnotations()
            }
        })
    }
    
    func zoomMapaFitAnnotations() {
        
        var zoomRect = MKMapRectNull
        for annotation in self.sessionMapView.annotations {
            
            let annotationPoint = MKMapPointForCoordinate(annotation.coordinate)
            
            let pointRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0, 0)
            
            if (MKMapRectIsNull(zoomRect)) {
                zoomRect = pointRect
            } else {
                zoomRect = MKMapRectUnion(zoomRect, pointRect)
            }
        }
        self.sessionMapView.setVisibleMapRect(zoomRect, edgePadding: UIEdgeInsetsMake(50, 50, 50, 50), animated: true)
    }
}
