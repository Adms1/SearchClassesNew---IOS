//
//  CustomVC.swift
//  Search Classes_New
//
//  Created by ADMS on 05/09/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var arrCoachList = [CoachModel]()
var coachType:CoachType = .none

var arrRegionData:[String] = []
var arrRegionSearchData:[String] = []

class CustomVC: UIViewController {
    
    @IBOutlet var viewPrevious:UIView!
    @IBOutlet var viewNext:UIView!
    @IBOutlet var lblNoRecord:UILabel!
    
    var dateFormatter = DateFormatter()
    var btnDate:UIButton!
    var datesArray: [Date] =  [Date]()
    var weeksArray: [String] =  [String]()
    
    var dicValues:[String:String] = [:]
    var dicStatus:[String:Bool] = [:]
    var arrData:[String] = []
    var arrCoachDetails = [CoachModel]()
    
    var arrExamData:[String] = []
    var arrActivityData:[String] = []
    
    var arrExamSearchData:[String] = []
    var arrActivitySearchData:[String] = []
    
    var arrInquiryList = [SCInquiryModel]()
    var arrCoachAutoCompleteList = [SCInquiryModel]()
    var arrClassRating = [CoachModel]()
    
    var activateField:DropDownTextField!
    
    var arrBoardData:[String] = []
    var arrStdData:[String] = []
    var arrLessonData:[String] = []
    var arrCityData:[String] = []
    
    var arrBoardSearchData:[String] = []
    var arrStdSearchData:[String] = []
    var arrLessonSearchData:[String] = []
    var arrCitySearchData:[String] = []
    
    var index = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(viewPrevious != nil) {
            (viewPrevious.subviews.first as! UIButton).setImage(#imageLiteral(resourceName: "down").rotate(radians: .pi/2), for: .normal)
            (viewNext.subviews.first as! UIButton).setImage(#imageLiteral(resourceName: "down").rotate(radians: -.pi/2), for: .normal)
        }
        
        guard !(self is SCMainVC) && !(self is SCSessionListVC) && !(self is SCLoginVC) && !(self is InquiryPopupVC) && !(self is ClassRatingVC) && !(self is SCPopupVC) && !(self is SCForgotPasswordVC) else {
            return
        }
        self.setupViewController()
    }
    
    func setupViewController()
    {
        let headerView = self.view.subviews[self is SCRegistrationVC || self is SCClassSearchVC || self is SCSessionDetailsVC ? 1 : 0]
        headerView.backgroundColor = (coachType == .register && self is SCRegistrationVC) || self is SCClassSearchVC ? .clear : (coachType == .register || self is SCSessionDetailsVC || self is SCSessionLocationVC) ? GetColor.headerColor : .white
        if(headerView.backgroundColor != .clear) {
            addShadow(headerView, 2.0, 0.2)
        }
        
        let imgHeader:UIImageView = headerView.subviews[0].subviews[1] as! UIImageView
        imgHeader.contentMode = .scaleAspectFit
        
        let lblHeader:UILabel = headerView.subviews[0].subviews[2] as! UILabel
        
        let btnMenu:UIButton = headerView.subviews[0].subviews[3] as! UIButton
        btnMenu.addTarget(self, action: #selector(btnMenuOpenAction(_:)), for: .touchUpInside)
        
        let btnBack:UIButton = headerView.subviews[0].subviews.last as! UIButton
        btnBack.isHidden = true
        btnBack.addTarget(self, action: #selector(btnBackAction(_:)), for: .touchUpInside)
        
        let viewFooter:UIView = headerView.subviews[0].subviews[0] as! UIView
        viewFooter.backgroundColor = headerView.backgroundColor == .white ? GetColor.headerColor : headerView.backgroundColor
        
        switch self {
        case is SCRegistrationVC, is AddAddressVC, is SelectCategoriesVC, is AddAvailabilityVC, is AboutUsVC:
            btnBack.isHidden = !(coachType == .register && self is SCRegistrationVC)
            imgHeader.isHidden = coachType == .register
            lblHeader.textColor = coachType == .register ? .white : GetColor.headerColor
            btnMenu.isHidden = coachType == .register
            if(coachType == .register) {
                lblHeader.text = self is SCRegistrationVC ? HeaderTitle.teacherRegister.rawValue : HeaderTitle.searchClassTitle.rawValue
            }else{
                lblHeader.text = self is SCRegistrationVC ? HeaderTitle.updateProfile.rawValue : HeaderTitle.searchClassUpdateTitle.rawValue
            }
        case is SCSessionDetailsVC, is SCClassSearchVC, is SCSessionLocationVC:
            btnBack.isHidden = false
            imgHeader.isHidden = true
            lblHeader.textColor = .white
            btnMenu.tintColor = .white
            btnMenu.isHidden = studentID == nil
            lblHeader.text = self is SCSessionDetailsVC ? HeaderTitle.classDetails.rawValue : self is SCSessionLocationVC ? HeaderTitle.classLocation.rawValue : HeaderTitle.classSearch.rawValue
        default:
            lblHeader.textColor = GetColor.headerColor
            imgHeader.isHidden = false
            btnMenu.tintColor = .darkGray
            btnMenu.isHidden = false
            lblHeader.text = HeaderTitle.inquiryTitle.rawValue
        }
    }
    
    lazy var inquiryPopupVC: InquiryPopupVC = {
        
        var viewController:InquiryPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "InquiryPopupVC") as! InquiryPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    lazy var scPopUpVC: SCPopupVC = {
        
        var viewController:SCPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "PopupVC") as! SCPopupVC
        viewController.arrFilterCoachData = arrCoachDetails
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    lazy var classRatingVC: ClassRatingVC = {
        
        var viewController:ClassRatingVC = Constants.storyBoard.instantiateViewController(withIdentifier: "ClassRatingVC") as! ClassRatingVC
        viewController.idx = index
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    lazy var forgotPasswordVC: SCForgotPasswordVC = {
        
        var viewController:SCForgotPasswordVC = Constants.storyBoard.instantiateViewController(withIdentifier: "SCForgotPasswordVC") as! SCForgotPasswordVC
        viewController.title = "Forgot Password"
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    func logOut() {
        self.logOutAction { (i) in
            if(i == 1){
                if(!(self is SCMainVC)){
                    Constants.appDelegate.makeAppRootController(SCViewControllerType.scMain.rawValue)
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension CustomVC
{
    @objc func dismissPicker(){
        if(activateField != nil){
            activateField.resignFirstResponder()
            if activateField.dropDownTableView.isHidden == false {
                activateField.dropDownTableView.isHidden = true
            }
        }
        self.view.endEditing(true)
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton) {
        pushViewController(self, "ClassSearchVC", "Search a Class")
    }
    
    @IBAction func btnBackAction(_ sender:UIButton?) {
        self.navigationController?.pushPopTransition(self, false, false)
    }
    
    @IBAction func btnBackRootAction(_ sender:UIButton?) {
        self.navigationController?.pushPopTransition(self, false, true)
    }
    
    @IBAction func btnCloseClicked(_ sender:UIButton) {
        sender.scaleAnimation(fromValue: 1.0, toValue: 0.001) {}
        self.removePopup((sender.superview?.subviews[0])!)
    }
    
    func removePopup(_ removeView:UIView?)
    {
        guard removeView != nil else {
            self.view.removeFromSuperview()
            self.removeFromParentViewController()
            return
        }
        
        removeView?.scaleAnimation(fromValue: 1.0, toValue: 0.001, completion: {
            self.view.removeFromSuperview()
            self.removeFromParentViewController()
        })
    }
    
    var addPopUpEffect: UIView
    {
        let mainView:UIView = self.view.subviews[0].subviews[0]
        mainView.layer.cornerRadius = 15.0
        if(self.view.subviews[0].subviews.count > 1){
            self.view.subviews[0].subviews[1].scaleAnimation(fromValue: 0.0, toValue: 1.0) {}
        }
        mainView.scaleAnimation(fromValue: 0.0, toValue: 1.0) {}
        return mainView
    }
}

extension CustomVC: CustomTableDelegate
{
    @IBAction func btnMenuOpenAction(_ sender:UIButton)
    {
        Constants.arrMenuItems = coachLoginID == nil ? ["Home", "Logout"] : [SCViewControllerType.scInquiry.rawValue, SCViewControllerType.scMyProfile.rawValue, "Logout"]
        
        var strValue:String!
        switch(self)
        {
        case is SCMainVC:
            strValue = "Home"
        case is SCRegistrationVC:
            strValue = SCViewControllerType.scMyProfile.rawValue
        case is InquiryVC:
            strValue = SCViewControllerType.scInquiry.rawValue
        default:
            break
        }
        self.removeValue(strValue)
        
        let tblVC = CustomTableViewController()
        tblVC.delegate = self
        tblVC.preferredContentSize = CGSize(width:DeviceType.isIphone5 ? 170 : 200, height:(Constants.arrMenuItems.count * (DeviceType.isIphone5 ? 30 : 40)) + 60)
        tblVC.modalPresentationStyle = .popover
        if let popover = tblVC.popoverPresentationController  {
            popover.delegate = self
            popover.sourceView = sender
            popover.sourceRect = sender.bounds.offsetBy(dx: 0, dy: 0)
            popover.permittedArrowDirections = .up
            self.present(tblVC, animated: true, completion: nil)
        }
    }
    
    func removeValue(_ value:String?)
    {
        if(value != nil){
            let idx:Int? = Constants.arrMenuItems.index(of: value!)
            if(idx != nil){
                Constants.arrMenuItems.remove(at: idx!)
            }
        }
    }
    
    func scPushView(_ controllerType: SCViewControllerType, _ title: String) {
        pushViewController(self, controllerType.rawValue, title)
    }
    
    func addViewController() {
        
    }
    
    func pushView(_ controllerType: ViewControllerType, _ title: String) {
        
    }
}

extension CustomVC: UIPopoverPresentationControllerDelegate
{
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
}

extension CustomVC
{
    // TODO: - ForgotPassword
    
    func callForgotPasswordApi(_ txtfld:UITextField)
    {
        self.callApi(API.forgotPassword, ["EmailAddress" : txtfld.text!]) { (json, error) in
            
            if(json != nil){
                showToast(MessageType.sentPassword.rawValue)
                self.removePopup(nil)
                
            }else if(json == nil){
                showToast(MessageType.noEmailRegister.rawValue)
                
            }else if(error != nil) {
                showAlertWithOkButton(["", MessageType.internetFailure.rawValue], completion: {
                    self.callForgotPasswordApi(txtfld)
                })
            }
        }
    }
    
    // TODO: - Register
    
    func callRegisterUpdateCoachApi(_ params: [String:String])
    {
        self.callApi(coachType == .myprofile ? API.updateCoach : API.createCoach, params) { (json, error) in
            
            if(json != nil) {
                
                UserDefaults.standard.set(json!["Coach_ID"].stringValue, forKey: "CoachID")
                pushViewController(self, SCViewControllerType.scAddress.rawValue, HeaderTitle.searchClassTitle.rawValue)
            }
        }
    }
    
    // TODO: - Email Exist Or Not
    
    func callEmailExistApi(_ txtfld:UITextField)
    {
        if !((txtfld.text?.isEmptyStr)!)
        {
            self.callApi(API.checkEmailAddress, ["EmailAddress" : txtfld.text!]) { (json, error) in
                
                if(json != nil) {
                    showToast(ErrorType.emaiExist.rawValue)
                    txtfld.text = nil
                    txtfld.becomeFirstResponder()
                    
                }else if(error != nil) {
                    showAlertWithOkButton(["", MessageType.internetFailure.rawValue], completion: {
                        self.callEmailExistApi(txtfld)
                    })
                }
            }
        }
    }
    
    // TODO: - Register
    
    func callGetCoachProfileDetailsApi(completion:@escaping (SCRegisterModel,Bool) -> ())
    {
        let params = ["Coach_ID" : coachID!]
        
        self.callApi(API.getCoach, params) { (json, error) in
            
            let coachData = json!["Data"].arrayValue.first
            
            let registerModel:SCRegisterModel = SCRegisterModel.init(fname: coachData!["FirstName"].stringValue, lname: coachData!["LastName"].stringValue, institueName: coachData!["InstituteName"].stringValue, eid: coachData!["EmailAddress"].stringValue, pwd: coachData!["Password"].stringValue, pno: coachData!["PhoneNumber"].stringValue, dob: coachData![""].stringValue, gid: coachData!["Gender_ID"].stringValue)
            
            completion(registerModel, coachData!["HasInstitute"].boolValue)
        }
    }
    
    // TODO: - Address
    
    func callAddAddress(_ params:[String:String])
    {
        self.callApi(API.addInstituteAddress, params) { (json, error) in
            
            if(json != nil) {
                
                selectType = .teachingType
                pushViewController(self, SCViewControllerType.scCategory.rawValue, HeaderTitle.searchClassTitle.rawValue)
            }
        }
    }
    
    func callGetAddress(completion:@escaping (SCAddressModel) -> ())
    {
        let params = ["Coach_ID" : coachID!]
        
        self.callApi(API.getInstituteAddress, params) { (json, error) in
            
            if(json != nil) {
                
                let addressData = json!["Data"].arrayValue.first
                
                let addressModel:SCAddressModel = SCAddressModel.init(addressLine1: addressData!["AddressLine1"].stringValue, addressLine2: addressData!["AddressLine2"].stringValue, area: addressData!["RegionName"].stringValue, city: addressData!["CityName"].stringValue, state: addressData!["StateName"].stringValue, zipCode: addressData!["AddressZipCode"].stringValue)
                
                completion(addressModel)
            }
        }
    }
    
    // TODO: - GetValues
    
    func callGetValuesApi(completion:@escaping () -> ())
    {
        dicStatus = [:]
        dicValues = [:]
        arrData = []
        
        var strApi:String!
        var strKey:String!
        var strValueKey:String!
        
        switch selectType {
        case .teachingType:
            strApi = API.getTeacherType
            strKey = "Teach_ID"
            strValueKey = "TeachName"
            
        case .boards:
            strApi = API.getBoardNew
            strKey = "Board_ID"
            strValueKey = "BoardName"
            
        case .levels:
            strApi = API.getStandardNew
            strKey = "Standard_ID"
            strValueKey = "StandardName"
            
        case .subjects:
            strApi = API.getSubjectNew
            strKey = "Subject_ID"
            strValueKey = "SubjectName"
            
        case .exams:
            strApi = API.getEntranceTest
            strKey = "EntranceTest_ID"
            strValueKey = "EntranceTestName"
            
        case .activity:
            strApi = API.getActivity
            strKey = "Activity_ID"
            strValueKey = "ActivityName"
            
        case .region:
            strApi = API.getRegionNew
            strKey = "Region_ID"
            strValueKey = "RegionName"
            
        default:
            break
        }
        
        self.callApi(strApi, ["Coach_ID" : coachID == nil ? "0" : coachID!]) { (json, error) in
            
            if(json != nil) {
                let jsonData = json!["Data"].array
                
                for value in jsonData! {
                    self.dicValues[value[strKey].stringValue] = value[strValueKey].stringValue
                    self.dicStatus[value[strValueKey].stringValue] = value["Status"].boolValue
                    self.arrData.append(value[strValueKey].stringValue)
                }
                completion()
            }
        }
    }
    
    // TODO: - GetValues
    
    func callAddEditValuesApi(completion:@escaping () -> ())
    {
        var strApi:String!
        var strKey:String!
        
        switch selectType {
        case .teachingType:
            strApi = API.aeTeacherType
            strKey = "Teach_ID"
            
        case .boards:
            strApi = API.aeBoardNew
            strKey = "Board_ID"
            
        case .levels:
            strApi = API.aeStandardNew
            strKey = "Standard_ID"
            
        case .subjects:
            strApi = API.aeSubjectNew
            strKey = "Subject_ID"
            
        case .exams:
            strApi = API.aeEntranceTest
            strKey = "EntranceTest_ID"
            
        case .activity:
            strApi = API.aeActivity
            strKey = "Activity_ID"
            
        default:
            break
        }
        
        let params = ["Coach_ID" : coachID!,
                      strKey! : dicSelectedValues[selectType]?.joined(separator: ",") as! String]
        
        self.callApi(strApi, params) { (json, error) in
            
            if(json != nil) {
                completion()
            }
        }
    }
    
    func callGetAvailability(completion:@escaping (String) -> ())
    {
        let params = ["Coach_ID" : coachID!]
        
        self.callApi(API.getCoachAvailability, params) { (json, error) in
            
            if(json != nil) {
                completion(json!["Data"].arrayValue.first!["Schedule"].stringValue)
            }
        }
    }
    
    func callAddAvailability(_ array:[String], completion:@escaping () -> ())
    {
        let params = ["Coach_ID" : coachID!,
                      "Schedule" : array.joined(separator: "|")]
        
        self.callApi(API.aeCoachAvailability, params) { (json, error) in
            
            if(json != nil) {
                completion()
            }
        }
    }
    
    func callAddAboutUs(_ strValue:String)
    {
        let params = ["Coach_ID" : coachID!,
                      "Description" : strValue]
        
        self.callApi(API.addInstituteDes, params) { (json, error) in
            
            if(json != nil) {
                self.callLogin(SCLoginModel.init(eid: emailID!, pwd: password!))
            }
        }
    }
    
    func callGetAboutUs(completion:@escaping (String) -> ())
    {
        let params = ["Coach_ID" : coachID!]
        
        self.callApi(API.getInstituteDes, params) { (json, error) in
            
            if(json != nil) {
                completion(json!["Data"].arrayValue.first!["Description"].stringValue)
            }
        }
    }
    
    func callLogin(_ loginModel:SCLoginModel)
    {
        let params = ["EmailAddress" : loginModel.strEmailAddress!,
                      "Password" : loginModel.strPassword!]
        
        self.callApi(API.loginCoach, params) { (json, error) in
            
            if(json != nil) {
                
                UserDefaults.standard.set(loginModel.strEmailAddress, forKey: "EmailID")
                UserDefaults.standard.set(json!["Data"].arrayValue.first!["FirstName"].stringValue + " " + json!["Data"].arrayValue.first!["LastName"].stringValue, forKey: "UserName")
                UserDefaults.standard.set(loginModel.strPassword, forKey: "Password")
                
                if(coachType == .none)
                {
                    UserDefaults.standard.set(json!["Data"].arrayValue.first!["Type"].stringValue, forKey: "LoginType")
                    
                    if(loginType == "Coach"){
                        UserDefaults.standard.set(json!["Data"].arrayValue.first!["Coach_ID"].stringValue, forKey: "CoachID")
                        UserDefaults.standard.set(coachID!, forKey: "CoachLoginID")
                        //                        Constants.appDelegate.makeAppRootController(SCViewControllerType.scInquiry.rawValue)
                        pushViewController(self, SCViewControllerType.scInquiry.rawValue, nil)
                    }else{
                        let sinquiryModel:SCInquiryModel = SCInquiryModel.init(fname: json!["Data"].arrayValue.first!["FirstName"].stringValue, lname: json!["Data"].arrayValue.first!["LastName"].stringValue, email: loginModel.strEmailAddress!, pwd: loginModel.strPassword!, pno: "")
                        
                        let encodedData = NSKeyedArchiver.archivedData(withRootObject: sinquiryModel)
                        UserDefaults.standard.set(encodedData, forKey: "UserData")
                        
                        UserDefaults.standard.set("0", forKey: "StudentID") // Its Dummy Value only for condition check
                        self.navigationController?.pushPopTransition(self, false, false)
                    }
                    return
                }
                showAlertWithOkButton(["", coachType == .myprofile ? MessageType.profileUpdate.rawValue : "Thank you for Register."], completion: {
                    UserDefaults.standard.set(coachID!, forKey: "CoachLoginID")
                    //Constants.appDelegate.makeAppRootController(SCViewControllerType.scInquiry.rawValue)
                    coachType = .none
                    pushViewController(self, SCViewControllerType.scInquiry.rawValue, nil)
                })
            }
        }
    }
    
    func callGetCoachDetails(_ apiName:String, _ params:[String:String], completion:@escaping () -> ())
    {        
        self.callApi(apiName, params) { (json, error) in
            
            if(json != nil) {
                
                let coachData = json!["Data"].array
                
                arrCoachList = []
                
                for values in coachData! {
                    
                    let coachModel:CoachModel = CoachModel(coachId: values["Coach_ID"].stringValue, coachName: values["Name"].stringValue, institueName: values["InstituteName"].stringValue, board: values["BoardName"].stringValue, std: values["StandardName"].stringValue, subject: values["SubjectName"].stringValue, activity: values["ActivityName"].stringValue, exam: values["EntranceTestName"].stringValue, address1: values["AddressLine1"].stringValue, address2: values["AddressLine2"].stringValue, region: values["RegionName"].stringValue, city: values["AddressCity"].stringValue, state: values["AddressState"].stringValue, country: values["CountryName"].stringValue, zipCode: values["AddressZipCode"].stringValue, availability: values["Schedule"].stringValue, duration: "", hasInstitute: values["HasInstitute"].stringValue, description: values["Description"].stringValue, email: values["EmailAddress"].stringValue, contactNo: values["PhoneNumber"].stringValue, ratingUser: values["TotalRatingUser"].intValue, rating: values["Rating"].doubleValue)
                    
                    arrCoachList.append(coachModel)
                    
                    selectedCoachData = coachModel
                }
                completion()
            }
        }
    }
    
    func callAddUserInquiry(_ params:[String:String], completion:@escaping () -> ())
    {        
        self.callApi(API.addUserAvailability, params) { (json, error) in
            
            if(json != nil) {
                completion()
            }
        }
    }
    
    func callAddUserRating(_ params:[String:String], completion:@escaping(Double) -> ())
    {
        self.callApi(API.addUserRating, params) { (json, error) in
            
            if(json != nil) {
                completion(json!["RateAvg"].doubleValue)
            }
        }
    }
    
    func callGetUserRating(_ params:[String:String], completion:@escaping () -> ())
    {
        self.callApi(API.getUserRating, params) { (json, error) in
            
            self.arrClassRating = []
            
            if(json != nil) {
                let jsonData = json!["Data"].array
                
                for value in jsonData! {
                    let classRatingModel = CoachModel.init(name: value["Name"].stringValue, rating: value["RatingValue"].doubleValue, comment: value["Comment"].stringValue, date: value["CreateDate"].stringValue)
                    
                    self.arrClassRating.append(classRatingModel)
                }
                completion()
            }else{
                completion()
            }
        }
    }
    
    func callGetInquiry(completion:@escaping () -> ())
    {
        let params = ["Coach_ID" : coachID!]
        
        self.callApi(API.getUserAvailability, params) { (json, error) in
            
            if(json != nil) {
                
                let inquiryData = json!["Data"].array
                
                self.arrInquiryList = []
                
                for values in inquiryData! {
                    
                    let inquiryModel:SCInquiryModel = SCInquiryModel(fname: values["Name"].stringValue, lname: values["Inquiry_ID"].stringValue, email: values["EmailAddress"].stringValue, pwd: "", pno: values["PhoneNumber"].stringValue, des: values["Description"].stringValue, board: values["BoardName"].stringValue, std: values["StandardName"].stringValue, subject: values["SubjectName"].stringValue, exam: values["EntranceTestName"].stringValue, activity: values["ActivityName"].stringValue, date: values["CreateDate"].stringValue)
                    
                    self.arrInquiryList.append(inquiryModel)
                }
                completion()
            }else if(json == nil){
                completion()
            }
        }
    }
    
    func callAutoCompleteData(completion:@escaping () -> ())
    {
        self.callApi(API.getAutoComplateList, [:]) { (json, error) in
            
            if(json != nil) {
                
                let coachData = json!["Data"].array
                
                self.arrCoachAutoCompleteList = []
                
                for values in coachData! {
                    
                    let inquiryModel:SCInquiryModel = SCInquiryModel(fname: "", lname: "", email: "", pwd: "", pno: "", des: "", board: values["BoardName"].stringValue, std: values["StandardName"].stringValue, subject: values["SubjectName"].stringValue, exam: values["EntranceTestName"].stringValue, activity: values["ActivityName"].stringValue, date: "")
                    
                    self.arrCoachAutoCompleteList.append(inquiryModel)
                }
                completion()
            }else if(json == nil){
                completion()
            }
        }
    }
}
