//
//  AddAvailabilityVC.swift
//  Search Classes
//
//  Created by ADMS on 15/03/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class AddAvailabilityVC: CustomVC {
    
    // MARK: - IBOutlet
    
    @IBOutlet var tblSessionTime:UITableView!
    @IBOutlet var selectionView:UIView!
    
    // MARK: - Variables
    
    var datesDic: [String:Date] =  [:]
    let timePicker: DPTimePicker = DPTimePicker.timePicker()
    var dicSessionValues:[String:String] = [:]
    var arrSelectedDays:[String] = []
    var isEdit = false
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for _ in 0..<7 {
            arrSelectedDays.append("true")
        }
        self.addTimePicker(self.view)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.hidesBackButton = true
        self.callGetAvailability { (strAvailability) in
            self.isEdit = true
            
            for (i,values) in strAvailability.components(separatedBy: "|").enumerated() {
                let subValues = values.components(separatedBy: ",")
                self.dicSessionValues[DateFormatter().weekdaySymbols[Int(subValues[0])!-1]] = "\(subValues[1]),\(subValues[2])"
                
                self.arrSelectedDays[i] = subValues[3].lowercased()
                self.tblSessionTime.reloadData()
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

// MARK: -  TableView DataSource & Delegate

extension AddAvailabilityVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: section == 0 ? "HeaderCell" : "AvailabilityHeaderCell")
        if(section == 1) {
            cell?.contentView.subviews[0].isHidden = true
            cell?.contentView.tag = 100
        }
        return cell?.contentView
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? 0 : 7
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.tableCellConfiguration("AvailabilityCell", indexPath)
        cell.contentView.tag = indexPath.row
        cell.tag = indexPath.row+101
        
        let lbl:UILabel = cell.contentView.subviews[0] as! UILabel
        let strDay:String = DateFormatter().weekdaySymbols[indexPath.row]
        lbl.text = strDay
        
        (cell.contentView.subviews[1] as! VKCheckbox).setOn(arrSelectedDays[indexPath.row].lowercased() == "true" ? true : false)
        (cell.contentView.subviews[2] as! UICollectionView).reloadData()
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.checkUncheckValues(indexPath: indexPath)
    }
}

// MARK: -  CollectionView DataSource & Delegate

extension AddAvailabilityVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width/CGFloat(collectionView.numberOfItems(inSection: 0)), height: (collectionView.superview?.frame.size.height)!)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.collectionCellConfiguration("AddSessionCell", indexPath)
        
        let lbl:UILabel = cell.contentView.subviews[1] as! UILabel
        if(collectionView.superview?.tag == 100) {
            lbl.text = "\(indexPath.row == 0 ? "Start" : "End") Time"
            
        } else {
            if(isEdit) {
                let strDay:String = DateFormatter().weekdaySymbols[((collectionView.superview!.superview?.tag)!%100)-1]
                var arrTimes = dicSessionValues[strDay]?.components(separatedBy: ",")
                lbl.text = arrTimes?[indexPath.row]
            }else {
                lbl.text = indexPath.row == 0 ? "7:00 AM" : "7:00 PM"
            }
            
            for btn in (cell.contentView.subviews.flatMap{$0 as? UIButton}){
                btn.tag = indexPath.row + 1
                btn.addTarget(self, action: #selector(btnAddDeleteTimeAction(_:)), for: .touchUpInside)
            }
            self.changeValueOfCell(cell, lbl.text!)
        }
        return cell
    }
}

// MARK: - Time Picker Delegate

extension AddAvailabilityVC: DPTimePickerDelegate
{
    func timePickerDidConfirm(_ hour: String, minute: String, slot: String, timePicker: DPTimePicker) {
        
        let array:[Int] = (timePicker.accessibilityValue?.components(separatedBy: "-").flatMap { Int($0) })!
        
        self.changeValue(array, "\(hour):\(minute) \(slot)")
    }
    
    func changeValue(_ tags:[Int], _ txt:String)
    {
        let tblCell:TableCell = tblSessionTime.viewWithTag(tags.first!) as! TableCell
        let cell0:CollectionCell =  (tblCell.contentView.subviews[2] as! UICollectionView).cellForItem(at: IndexPath.init(row: 0, section: 0)) as! CollectionCell
        let cell1:CollectionCell =  (tblCell.contentView.subviews[2] as! UICollectionView).cellForItem(at: IndexPath.init(row: 1, section: 0)) as! CollectionCell
        
        let strDay:String = (tblCell.contentView.subviews[0] as! UILabel).text!
        
        if(tags.last!-1 == 0){
            if(txt != strAdd){
                cell1.alpha = 1
                cell1.isUserInteractionEnabled = true
                
            }else {
                cell1.alpha = 0.5
                cell1.isUserInteractionEnabled = false
                self.changeValueOfCell(cell1, txt)
            }
        }else{
            cell1.alpha = 1
            cell1.isUserInteractionEnabled = true
        }
        
        let cell:CollectionCell =  (tblCell.contentView.subviews[2] as! UICollectionView).cellForItem(at: IndexPath.init(row: tags.last!-1, section: 0)) as! CollectionCell
        
        /*
         */
        
        var startTime:String = ""
        var endTime:String = ""
        
        if tags.last!-1 == 0 && (cell1.contentView.subviews[1] as! UILabel).text != strAdd {
            startTime = txt
            endTime = (cell1.contentView.subviews[1] as! UILabel).text!
            
        } else if(tags.last!-1 == 1 && (cell0.contentView.subviews[1] as! UILabel).text != strAdd) {
            startTime = (cell0.contentView.subviews[1] as! UILabel).text!
            endTime = txt
            
        } else {
            self.changeValueOfCell(cell, txt)
            dicSessionValues.removeValue(forKey: strDay)
            return
        }
        
        let result = calculateTimeDifference(startTime, endTime, ErrorType.validTime.rawValue)
        if result.0 {
            self.changeValueOfCell(cell, txt)
            dicSessionValues[strDay] = "\(startTime),\(endTime)"
        }
    }
    
    // MARK: - Change CollectionCell Values
    
    func changeValueOfCell(_ cell:CollectionCell, _ txt:String)
    {
        (cell.contentView.subviews[1] as! UILabel).text = txt
        
        (cell.contentView.subviews[3] as! UIButton).isHidden = false
        cell.trealingConstant.constant = (cell.contentView.subviews[3] as! UIButton).isHidden ? 8 : 35
        
        (cell.contentView.subviews[3] as! UIButton).setTitle(txt == strAdd ? "+" : "×", for: .normal)
        (cell.contentView.subviews[3] as! UIButton).layer.borderColor = txt == strAdd ? GetColor.headerColor.cgColor : GetColor.radioColorRed.cgColor
        (cell.contentView.subviews[3] as! UIButton).setTitleColor(txt == strAdd ? GetColor.headerColor : GetColor.radioColorRed, for: .normal)
        
        if txt == strAdd {
            (cell.contentView.subviews[2] as! UIButton).addTarget(self, action: #selector(btnAddDeleteTimeAction(_:)), for: .touchUpInside)
        }else {
            (cell.contentView.subviews[2] as! UIButton).addTarget(self, action: #selector(btnEditTimeAction(_:)), for: .touchUpInside)
        }
        cell.contentView.subviews[2].accessibilityValue = txt
    }
    
    func checkUncheckValues(indexPath:IndexPath)
    {
        let cell:TableCell = tblSessionTime.cellForRow(at: indexPath) as! TableCell
        let isCheck = ((cell.contentView.subviews[1] as? VKCheckbox)?.isOn())!
        (cell.contentView.subviews[1] as? VKCheckbox)?.setOn(!isCheck, animated: true)
        //        if(indexPath.row < arrSelectedDays.count) {
        arrSelectedDays[indexPath.row] = !isCheck ? "true" : "false"
        //        }else{
        //arrSelectedDays.append(!isCheck ? "true" : "false")
        //        }
        print(arrSelectedDays)
    }
}

// MARK: - Button Actions

extension AddAvailabilityVC
{
    @objc func btnAddDeleteTimeAction(_ sender:UIButton)
    {
        let superViewTag = (sender.superview?.superview?.superview?.superview?.superview?.tag)!
        
        if sender.titleLabel?.text == "×" {
            self.changeValue([superViewTag,sender.tag], strAdd)
        }else {
            self.resetTimePicker(nil, nil, nil)
            timePicker.accessibilityValue = "\(superViewTag)-\(sender.tag)"
            timePicker.show(nil)
        }
    }
    
    @objc func btnEditTimeAction(_ sender:UIButton)
    {
        let values:[String] = (sender.accessibilityValue?.components(separatedBy: " ").first?.components(separatedBy: ":"))!
        self.resetTimePicker((values.first)!, (values.last)!, (sender.accessibilityValue?.components(separatedBy: " ").last)!)
        timePicker.show(nil)
    }
    
    @IBAction func btnNextPreviousAction(_ sender:UIButton)
    {
        if(sender.tag == 1){
            if(!arrSelectedDays.contains("true")){
                showToast("Please select atleast one availability")
                return
            }
            var array:[String] = []
            for (i,strTimeSelection) in arrSelectedDays.enumerated() {
                let day = dicSessionValues[DateFormatter().weekdaySymbols[i]] ?? "7:00 AM,7:00 PM"
                array.append("\(i+1),\(day),\(strTimeSelection)")
            }
            self.callAddAvailability(array, completion: {
                pushViewController(self, SCViewControllerType.scAboutUs.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
            })
        }else{
            self.navigationController?.pushPopTransition(self, false, false)
        }
    }
}

// MARK: - Functions

extension AddAvailabilityVC
{
    func addTimePicker(_ insertView:UIView)
    {
        timePicker.insertInView(insertView)
        timePicker.delegate = self
        self.resetTimePicker(nil, nil, nil)
    }
    
    func resetTimePicker(_ initHour:String?, _ initMinute:String?, _ initSlot:String?)
    {
        timePicker.isHidden = false
        if initHour == nil && initHour == nil && initSlot == nil {
            let strCurrentTime:String = Date().toString(dateFormat: timeFormate)
            timePicker.initialHour = (strCurrentTime.components(separatedBy: " ").first?.components(separatedBy: ":").first)!
            timePicker.initialMinute = (strCurrentTime.components(separatedBy: " ").first?.components(separatedBy: ":").last)!
            timePicker.initialSlot = strCurrentTime.components(separatedBy: " ").last!
        } else {
            timePicker.initialHour = initHour!
            timePicker.initialMinute = initMinute!
            timePicker.initialSlot = initSlot!
        }
    }
}


