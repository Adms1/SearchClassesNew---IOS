//
//  AddAddressVC.swift
//  Search Classes_New
//
//  Created by ADMS on 07/09/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var selectType:Category = .region
class AddAddressVC: CustomVC {
    
    var dicStateCity:[String:[String]] = [:]
    var dicCityState:[String:String] = [:]
    
    var arrStateData:[String] = []
    var arrStateSearchData:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(txtFldDidEndEditing(_:)), name: .getCityStateResults, object: nil)
        
        self.getValues()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        selectType = .region
        self.callGetValuesApi {
            arrRegionData = self.dicValues.values.sorted(by: <)
            arrRegionSearchData = arrRegionData.map { $0 }
            
            self.callGetAddress(completion: { (addressModel) in
                
                let array = [addressModel.strAddressLine1, addressModel.strAddressLine2, addressModel.strArea, addressModel.strCity, addressModel.strState, addressModel.strZipCode]
                
                for (i,txt) in (self.view.subviews.flatMap{$0 as? UITextField}).enumerated() {
                    txt.text = array[i]
                }
            })
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AddAddressVC
{
    func getValues()
    {
        let text = try! String(contentsOfFile: Bundle.main.path(forResource: "world-cities", ofType: "txt")!) // Reading File
        let lineArray = text.components(separatedBy: "\n") // Separating Lines
        
        for eachLA in lineArray
        {
            let wordArray = eachLA.components(separatedBy: ",")
            if(wordArray.count == 4)
            {
                if(wordArray[1].caseInsensitiveCompare("india") == ComparisonResult.orderedSame)
                {
                    self.dicCityState[wordArray[0]] = wordArray[2]
                    if(self.dicStateCity[wordArray[2]] == nil)
                    {
                        self.dicStateCity[wordArray[2]] = [wordArray[0]]
                    }
                    else
                    {
                        var arrCities:[String] = self.dicStateCity[wordArray[2]]!
                        arrCities.append(wordArray[0])
                        self.dicStateCity[wordArray[2]] = arrCities
                    }
                }
            }
        }
        self.addAutoCompleteMenu()
    }
    
    // TODO: - AutoCompleteMenu
    
    func addAutoCompleteMenu()
    {
        for view in self.view.subviews.filter({($0.isKind(of: DropDownTextField.classForCoder()))}) {
            
            let dropDownTextField:DropDownTextField = view as! DropDownTextField
            activateField = dropDownTextField
            
            dropDownTextField.dropDownTableView.tag = 1
            dropDownTextField.dropDownTableView.dataSource = self
            dropDownTextField.dropDownTableView.delegate = self
            
            dropDownTextField.dropDownTableView.isHidden = true
            dropDownTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        }
    }
    
    @IBAction func btnNextPreviousAction(_ sender:UIButton)
    {
        let textFields:[UITextField] = self.view.subviews as! [UITextField]
        
        let addressModel:SCAddressModel = SCAddressModel.init(addressLine1: textFields[1].text!, addressLine2: textFields[2].text!, area: textFields[3].text!, city: textFields[4].text!, state: textFields[5].text!, zipCode: textFields[6].text!)
        
        let erroTypes:[ErrorType] = [.address, .address, .area, .city, .state, .zipCode]
        
        let result = SCAddressModel.addressValidation(Mirror(reflecting: addressModel), erroTypes)
        
        if result.0 {
            
            let params = ["Coach_ID" : coachID!,
                          "AddressLine1" : addressModel.strAddressLine1,
                          "AddressLine2" : addressModel.strAddressLine2,
                          "region" : addressModel.strArea,
                          "CityName" : addressModel.strCity,
                          "StateName" : addressModel.strState,
                          "AddressZipCode" : addressModel.strZipCode,
                          "Country" : "India"
            ]
            
            callAddAddress(params)
        }else {
            textFields[result.1+1].showErrorView
        }
    }
}

extension AddAddressVC: UITextFieldDelegate
{
    @objc func textFieldDidChange(_ textField: DropDownTextField) {
        
        let textFields:[UITextField] = self.view.subviews as! [UITextField]
        
        if activateField.dropDownTableView.isHidden == false {
            activateField.dropDownTableView.isHidden = true
        }
        activateField = textField
        
        var array:[String] = []
        var arraySearch:[String] = []
        
        switch textField.placeholder! {
        case "Area":
            arraySearch = arrRegionSearchData.map { $0 }
            
        case "State":
            arrStateSearchData = Array(dicStateCity.keys).sorted(by: <)
            arraySearch = arrStateSearchData.map { $0 }
            
        default:
            if(textFields[5].text!.isEmptyStr) { // State
                arrCitySearchData = Array(dicCityState.keys).sorted(by: <)
            }
            else {
                arrCitySearchData = (dicStateCity[textFields[5].text!]?.sorted(by: <))!
            }
            arraySearch = arrCitySearchData.map { $0 }
        }
        
        let filtered = arraySearch.filter { $0.range(of: textField.text!, options: .caseInsensitive) != nil }
        array = textField.text == "" ? [] : filtered
        
        switch textField.placeholder! {
        case "Area":
            arrRegionData = array.map { $0 }
        case "City":
            arrCityData = array.map { $0 }
        default:
            arrStateData = array.map { $0 }
        }
        
        if(array.count == 0){
            textField.dropDownTableView.isHidden = true
            return
        }
        textField.dropDownTableView.setUpTblHeight(array)
        textField.dropDownTableView.isHidden = false
    }
    
    @objc func txtFldDidEndEditing(_ notification: NSNotification)
    {
        let textFields:[UITextField] = self.view.subviews as! [UITextField]
        
        switch activateField.placeholder! {
        case "City":
            if(!(activateField.text!.isEmptyStr)){
                if(dicCityState[caseInsensitive: activateField.text!] != nil){
                    textFields[5].text! = dicCityState[caseInsensitive: activateField.text!]!
                }else {
                    textFields[5].text! = ""
                }
            }
        case "State":
            if(!(activateField.text!.isEmptyStr)){
                if let values = dicStateCity[caseInsensitive: activateField.text!] {
                    if values.contains(where: {$0.caseInsensitiveCompare(textFields[4].text!) != .orderedSame}) {
                        textFields[4].text! = ""
                    }
                }
            }
        default:
            break
        }
    }
}

extension AddAddressVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch activateField.placeholder! {
        case "Area":
            return arrRegionData.count
        case "City":
            return arrCityData.count
        default:
            return arrStateData.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = activateField.dropDownTableView.dequeueReusableCell(withIdentifier: "Cell")
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "Cell")
            cell?.selectionStyle = .none
        }
        
        var array:[String] = []
        switch activateField.placeholder! {
        case "Area":
            array = arrRegionData
        case "City":
            array = arrCityData
        default:
            array = arrStateData
        }
        
        cell?.textLabel?.font = FontHelper.regular(size: DeviceType.isIpad ? 15 :12)
        cell!.textLabel!.attributedText = array[indexPath.row].makeBoldSubString(activateField.text!, FontHelper.bold(size: DeviceType.isIpad ? 15 :12), false, .black, .black)
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = activateField.dropDownTableView.cellForRow(at: indexPath)
        activateField.text = cell?.textLabel?.text
        
        let textFields:[UITextField] = self.view.subviews as! [UITextField]
        
        if(activateField.placeholder == "City" && !(activateField.text!.isEmptyStr)) {
            textFields[5].text! = dicCityState[activateField.text!]!
            
        }else if(activateField.placeholder == "State"){
            
            let values = dicStateCity[activateField.text!]
            if(!((values?.contains(textFields[4].text!))!)) {
                textFields[4].text! = ""
            }
        }
        self.dismissPicker()
    }
}
