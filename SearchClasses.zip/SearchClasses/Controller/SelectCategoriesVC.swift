//
//  SelectCategoriesVC.swift
//  Search Classes_New
//
//  Created by ADMS on 05/09/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var dicSelectedValues:[Category:[String]] = [:]
class SelectCategoriesVC: CustomVC {
    
    @IBOutlet var tblValues:UITableView!
    @IBOutlet var pageControl:UIPageControl!
    
    var arrValues:[String] = []
    var isFocus:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.hidesBackButton = true
        
        pageControl.isHidden = selectType == .teachingType
        pageControl.numberOfPages = 0
        
        if(dicSelectedValues[.teachingType] != nil) {
            if (dicSelectedValues[.teachingType]?.contains("1"))! && (dicSelectedValues[.teachingType]?.contains("2"))! && (dicSelectedValues[.teachingType]?.contains("3"))! {
                pageControl.numberOfPages = 5
                
            }else if (dicSelectedValues[.teachingType]?.contains("1"))! {
                pageControl.numberOfPages = 3
                
                if (dicSelectedValues[.teachingType]?.contains("2"))! || (dicSelectedValues[.teachingType]?.contains("3"))! {
                    pageControl.numberOfPages += 1
                }
            }else {
                if (dicSelectedValues[.teachingType]?.contains("2"))! && (dicSelectedValues[.teachingType]?.contains("3"))! {
                    pageControl.numberOfPages = 2
                }else{
                    pageControl.numberOfPages = 1
                }
            }
        }
        pageControl.currentPage = selectType.hashValue > 0 ? selectType.hashValue - 1 : 0
        
        self.callGetValuesApi {
            //            self.arrValues = selectType == .teachingType ? self.arrData : self.dicValues.values.sorted(by: <)
            self.arrValues = self.arrData
            self.tblValues.reloadData()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SelectCategoriesVC
{
    @IBAction func btnNextPreviousAction(_ sender:UIButton)
    {
        if(sender.tag == 1){
            guard dicSelectedValues[selectType] != nil else {
                showToast("Please select atleast one option")
                return
            }
            switch(selectType)
            {
            case .teachingType :
                if (dicSelectedValues[.teachingType]?.contains("1"))!{
                    self.callAddEditValuesApi {
                        selectType = .boards
                        pushViewController(self, SCViewControllerType.scCategory.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                    }
                }else if (dicSelectedValues[.teachingType]?.contains("2"))!{
                    self.callAddEditValuesApi {
                        selectType = .exams
                        pushViewController(self, SCViewControllerType.scCategory.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                    }
                }else{
                    self.callAddEditValuesApi {
                        selectType = .activity
                        pushViewController(self, SCViewControllerType.scCategory.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                    }
                }
            case .boards :
                self.callAddEditValuesApi {
                    selectType = .levels
                    pushViewController(self, SCViewControllerType.scCategory.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                }
            case .levels :
                self.callAddEditValuesApi {
                    selectType = .subjects
                    pushViewController(self, SCViewControllerType.scCategory.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                }
            case .subjects:
                if (dicSelectedValues[.teachingType]?.contains("2"))!{
                    self.callAddEditValuesApi {
                        selectType = .exams
                        pushViewController(self, SCViewControllerType.scCategory.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                    }
                }else if (dicSelectedValues[.teachingType]?.contains("3"))!{
                    self.callAddEditValuesApi {
                        selectType = .activity
                        pushViewController(self, SCViewControllerType.scCategory.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                    }
                }else{
                    self.callAddEditValuesApi {
                        pushViewController(self, SCViewControllerType.scAvailabilty.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                    }
                }
            case .exams:
                if (dicSelectedValues[.teachingType]?.contains("3"))!{
                    self.callAddEditValuesApi {
                        selectType = .activity
                        pushViewController(self, SCViewControllerType.scCategory.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                    }
                }else{
                    self.callAddEditValuesApi {
                        pushViewController(self, SCViewControllerType.scAvailabilty.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                    }
                }
            case .activity:
                self.callAddEditValuesApi {
                    pushViewController(self, SCViewControllerType.scAvailabilty.rawValue, coachType == .myprofile ? HeaderTitle.searchClassUpdateTitle.rawValue : HeaderTitle.searchClassTitle.rawValue)
                }
            default:
                break
            }
        }else{
            switch(selectType)
            {
            case .boards : selectType = .teachingType
            case .levels : selectType = .boards
            case .subjects : selectType = .levels
            case .exams :
                if (dicSelectedValues[.teachingType]?.contains("1"))! && (dicSelectedValues[.teachingType]?.contains("2"))!{
                    selectType = .subjects
                }else{
                    selectType = .teachingType
                }
            case .activity :
                if (dicSelectedValues[.teachingType]?.contains("1"))! && (dicSelectedValues[.teachingType]?.contains("3"))!{
                    selectType = .subjects
                }else if (dicSelectedValues[.teachingType]?.contains("2"))! && (dicSelectedValues[.teachingType]?.contains("3"))!{
                    selectType = .exams
                }else {
                    selectType = .teachingType
                }
            default:
                break
            }
            self.navigationController?.pushPopTransition(self, false, false)
        }
    }
}

extension SelectCategoriesVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell:TableCell = tableView.dequeueReusableCell(withIdentifier: "HeaderCell") as! TableCell
        cell.displayValues(TitleArray.arrTitle[selectType.hashValue], "", dicStatus)
        return cell.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return selectType != .teachingType && indexPath.row == 0 ? 56 : 40
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrValues.count + (selectType != .teachingType ? 1 : 0)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let strIdentifier:String = selectType != .teachingType && indexPath.row == 0 ? "SearchCell" : "ItemCell"
        let cell = tableView.tableCellConfiguration(strIdentifier, indexPath)
        
        if(selectType != .teachingType){
            cell.searchValues = { strvalue in
                self.arrValues = strvalue == "" ? self.dicValues.values.sorted(by: <) : self.dicValues.values.filter{$0.contains(strvalue)}.map{$0}.sorted(by: <)
                self.tblValues.reloadData()
                if(indexPath.row > 0) {
                    cell.displayValues(self.arrValues[indexPath.row - 1], strvalue, self.dicStatus)
                    self.addRemoveValues(indexPath.row - 1, !((cell.contentView.subviews[1] as? VKCheckbox)?.isOn())!)
                    //                    cell.changeValues = { isCheck in
                    //                        self.addRemoveValues(indexPath.row - 1, isCheck)
                    //                    }
                }
            }
            if(indexPath.row > 0) {
                cell.displayValues(self.arrValues[indexPath.row - 1], "", self.dicStatus)
                self.addRemoveValues(indexPath.row - 1, !((cell.contentView.subviews[1] as? VKCheckbox)?.isOn())!)
                //                cell.changeValues = { isCheck in
                //                    self.addRemoveValues(indexPath.row - 1, isCheck)
                //                }
            }else {
                if(isFocus) {
                    cell.contentView.subviews[0].subviews[0].becomeFirstResponder()
                }
            }
        }else{
            cell.displayValues(self.arrValues[indexPath.row], "", self.dicStatus)
            self.addRemoveValues(indexPath.row, !((cell.contentView.subviews[1] as? VKCheckbox)?.isOn())!)
            //            cell.changeValues = { isCheck in
            //                self.addRemoveValues(indexPath.row, isCheck)
            //            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(selectType != .teachingType && indexPath.row == 0){
            return
        }
        self.checkUncheckValues(indexPath: indexPath)
    }
    
    func checkUncheckValues(indexPath:IndexPath)
    {
        let cell:TableCell = tblValues.cellForRow(at: indexPath) as! TableCell
        let isCheck = ((cell.contentView.subviews[1] as? VKCheckbox)?.isOn())!
        (cell.contentView.subviews[1] as? VKCheckbox)?.setOn(!isCheck, animated: true)
        
        let index = indexPath.row - (selectType != .teachingType ? 1 : 0)
        self.dicStatus[self.arrValues[index]] = !isCheck
        print(dicStatus)
        
        self.addRemoveValues(index, isCheck)
    }
    
    func addRemoveValues(_ index:NSInteger, _ isCheck:Bool)
    {
        let strKey:String = (dicValues as NSDictionary).allKeys(for: arrValues[index]).first as! String
        
        if(dicSelectedValues[selectType] != nil){
            var array = dicSelectedValues[selectType]
            if(!isCheck) {
                if(!((array?.contains(strKey))!)) {
                    array?.append(strKey)
                    dicSelectedValues[selectType] = array
                }
            }else {
                if let idx = (array?.index(of: strKey)) {
                    array?.remove(at: idx)
                    if(array?.count == 0){
                        dicSelectedValues.removeValue(forKey: selectType)
                        return
                    }
                    dicSelectedValues[selectType] = array
                }
            }
        }else{
            if !isCheck {
                dicSelectedValues[selectType] = [strKey]
            }
        }
        //        print(dicSelectedValues)
    }
}

extension SelectCategoriesVC: UISearchBarDelegate
{
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isFocus = true
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let filtered = self.dicValues.values.sorted(by: <).filter { $0.range(of: searchText, options: .caseInsensitive) != nil }
        self.arrValues = searchBar.text == "" ? self.dicValues.values.sorted(by: <) : filtered
        self.tblValues.reloadData()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        isFocus = false
        self.view.endEditing(true)
    }
}
