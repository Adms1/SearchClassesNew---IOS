//
//  SCPopupVC.swift
//  Search Classes
//
//  Created by ADMS on 09/03/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var viewTag:Int = 0
var strPopupTitle:String = ""

var ratingSortType:RatingSortType = .none
var locationSortType:LocationSortType = .none

protocol SCPopupVCDelegate {
    func filterSessionBasedOnBottomMenu()
    func filterSessionBasedOnLocation()
}

class SCPopupVC: CustomVC {
    
    @IBOutlet var mainView:UIView!
    @IBOutlet var leadingValue:NSLayoutConstraint!
    @IBOutlet var popupHeight:NSLayoutConstraint!
    @IBOutlet var rangeInfoLbl:UILabel!
    
    var arrFilterCoachData = [CoachModel]()
    var delegate:SCPopupVCDelegate!
    var resultCount = 0
    var arrRegionResults:[String] = []
    var dicRegionCount:[String:Int] = [:]
    
    //  Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        self.showPopUpWithAnimation()
    }
    
    func showPopUpWithAnimation()
    {
        NotificationCenter.default.post(name: .selectedMenu, object: nil, userInfo: ["tag" : viewTag])
        
        leadingValue.constant = ((self.view.frame.size.width/3) * (CGFloat(viewTag/10) - 1))
        
        for view in self.mainView.subviews[0].subviews {
            if(view.tag != 0) {
                view.isHidden = true
                
                if(view.tag == viewTag) {
                    view.isHidden = false
                    
                    self.mainView.transform = CGAffineTransform.init(translationX: 0, y: self.view.frame.size.height)
                    UIView.animate(withDuration: 0.5) {
                        self.mainView.transform = CGAffineTransform.init(translationX: 0, y: 0)
                    }
                    if(viewTag == 20){
                        if(strSelectedRegion != ""){
                            rangeInfoLbl.text = "\(arrRegionSearchData.count) of \(arrRegionSearchData.count) Results"
                        }else{
                            if(arrRegionSearchData.count > 0){
                                rangeInfoLbl.text = "\(arrRegionSearchData.count) of \(arrRegionData.count) Results"
                            }else {
                                self.rangeInfoLbl.text = "Top \(arrRegionData.count) Results"
                            }
                        }
                        //                        arrRegionResults = strSelectedRegion == "" ? arrRegionData : arrRegionSearchData
                        arrRegionResults = arrRegionData
                        for region in arrRegionResults {
                            let results = arrCoachList.filter{$0.strRegion.caseInsensitiveCompare(region) == .orderedSame}
                            dicRegionCount[region] = results.count
                        }
                        self.popupHeight.constant = CGFloat(arrRegionResults.count > 4 ? 200 : arrRegionResults.count * 50)
                        (view.subviews[0] as! UITableView).reloadData()
                    }else {
                        self.popupHeight.constant = viewTag == 30 ? 130 : 150
                    }
                    self.popupHeight.constant += 90
                }
            }else {
                (view.subviews[0].subviews[0] as! UILabel).text = strPopupTitle
                (view.subviews[0].subviews[1] as! UIButton).addTarget(self, action: #selector(btnDoneAction), for: .touchUpInside)
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if let touch = touches.first {
            let position = touch.location(in: self.view)
            
            if(position.y >= self.view.frame.size.height - 70)
            {
                mainView.transform = CGAffineTransform.init(translationX: 0, y: 0)
                UIView.animate(withDuration: 0.5, animations: {
                    self.mainView.transform = CGAffineTransform.init(translationX: 0, y: self.mainView.frame.size.height + 100)
                }) { (finish) in
                    self.checkInRange(Int(position.x), 0, Int(self.view.frame.size.width/3))
                }
            }
        }
    }
    
    // Check Range As per Touch for TabBar
    
    func checkInRange(_ checkPoint:Int, _ start:Int, _ end:Int)
    {
        let singleItemSize:Int = Int(self.view.frame.size.width/3)
        
        if !(start..<end).contains(checkPoint) {
            self.checkInRange(checkPoint, end, end+singleItemSize)
            
        }else {
            viewTag = (end/singleItemSize) * 10
            switch(viewTag)
            {
            case 20:
                strPopupTitle = "LOCATION"
            case 30:
                strPopupTitle = "SORT"
            default:
                break
            }
            
            if(viewTag != 10){
                guard arrFilterCoachData.count > 0 else {
                    NotificationCenter.default.post(name: .clearSelectedMenu, object: nil)
                    self.removePopup(nil)
                    showToast(MessageType.noFilterOption.rawValue)
                    return
                }
            }
            self.showPopUpWithAnimation()
        }
    }
    
    @objc func btnDoneAction()
    {
        mainView.transform = CGAffineTransform.init(translationX: 0, y: 0)
        
        UIView.animate(withDuration: 0.5, animations: {
            self.mainView.transform = CGAffineTransform.init(translationX: 0, y: self.mainView.frame.size.height + 100)
        }) { (finish) in
            
            NotificationCenter.default.post(name: .clearSelectedMenu, object: nil)
            self.removePopup(nil)
            
            if(viewTag == 20) {
                self.delegate.filterSessionBasedOnLocation()
            }else {
                self.delegate.filterSessionBasedOnBottomMenu()
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

//  Filter

extension SCPopupVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.tableFooterView = UIView()
        return 50
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView.tag == 20 ? arrRegionResults.count : Constants.arrSCSortItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.tableCellConfiguration("TableCell", indexPath)
        cell.contentView.tag = (indexPath.row+1)*1000
        
        if(tableView.tag == 10)
        {
            (cell.contentView.subviews[0] as! UIImageView).image = UIImage.init(named: Constants.arrSCSortItem[indexPath.row])
            (cell.contentView.subviews[1] as! UILabel).text = Constants.arrSCSortItem[indexPath.row].uppercased()
            switch(indexPath.row)
            {
            case 0:
                (cell.contentView.subviews[3] as! UILabel).text = "Lowest First"
                (cell.contentView.subviews[5] as! UILabel).text = "Highest First"
            case 1:
                (cell.contentView.subviews[3] as! UILabel).text = "A to Z"
                (cell.contentView.subviews[5] as! UILabel).text = "Z to A"
            default:
                break
            }
            self.setRadioButtons(cell, tableView)
        }
        else
        {
            (cell.contentView.subviews[1] as! UILabel).text = arrRegionResults[indexPath.row]
            (cell.contentView.subviews[2] as! UILabel).text = "(\(dicRegionCount[arrRegionResults[indexPath.row]]!))"
            
            if(arrRegionSearchData.contains(arrRegionResults[indexPath.row])){
                (cell.contentView.subviews[0] as! VKCheckbox).setOn(true, animated: true)
            }else{
                (cell.contentView.subviews[0] as! VKCheckbox).setOn(false, animated: true)
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(tableView.tag == 20)
        {
            if(arrRegionSearchData.contains(arrRegionResults[indexPath.row])){
                let idx:NSInteger = arrRegionSearchData.index(of: arrRegionResults[indexPath.row])!
                arrRegionSearchData.remove(at: idx)
            }else {
                arrRegionSearchData.append(arrRegionResults[indexPath.row])
            }
            
            if(arrRegionSearchData.count == 0)
            {
                self.rangeInfoLbl.text = "Top \(arrRegionResults.count) Results"
            }
            else
            {
                rangeInfoLbl.text = "\(arrRegionSearchData.count) of \(strSelectedRegion == "" ? arrRegionResults.count : arrRegionSearchData.count) Results"
            }
            
            if(strSelectedRegion == "")
            {
                tableView.reloadRows(at: [IndexPath.init(row: indexPath.row, section: 0)], with: .automatic)
            }
            else
            {
                tableView.reloadData()
            }
        }
    }
}

extension SCPopupVC
{
    func setRadioButtons(_ cell:TableCell, _ tblView:UITableView)
    {
        for view in cell.contentView.subviews {
            view.layoutIfNeeded()
            
            if(view.isKind(of: UIButton.classForCoder())) {
                let radioButton:UIButton = view as! UIButton
                radioButton.layer.cornerRadius = radioButton.frame.size.width/2
                radioButton.layer.borderColor = UIColor.lightGray.cgColor
            }
            
            if(view.tag != 0) {
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.addGestureRecognizer(tapGesture)
            }
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        if let tblView = gesture.view?.superview?.superview?.superview as? UITableView {
            for visibleCell in tblView.visibleCells {
                for view in visibleCell.contentView.subviews {
                    if(view.isKind(of: UIButton.classForCoder())) {
                        let radioButton:UIButton = view as! UIButton
                        radioButton.layer.borderColor = UIColor.lightGray.cgColor
                    }
                }
            }
        }
        
        let tag:NSInteger = (gesture.view?.tag)! > 20 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        let radioButton:UIButton = gesture.view?.superview?.viewWithTag(tag) as! UIButton
        
        ratingSortType = .none
        locationSortType = .none
        
        if(gesture.view?.superview?.tag == 1000)
        {
            if(ratingSortType == (tag == 10 ? .low : .high)) {
                radioButton.layer.borderColor = UIColor.lightGray.cgColor
                ratingSortType = .none
            }else{
                radioButton.layer.borderColor = GetColor.radioColorRed.cgColor
                ratingSortType = (tag == 10 ? .low : .high)
            }
        }
        else
        {
            if(locationSortType == (tag == 10 ? .low : .high)) {
                radioButton.layer.borderColor = UIColor.lightGray.cgColor
                locationSortType = .none
            }else{
                radioButton.layer.borderColor = GetColor.radioColorRed.cgColor
                locationSortType = (tag == 10 ? .low : .high)
            }
        }
    }
}
