//
//  InquiryVC.swift
//  Search Classes_New
//
//  Created by ADMS on 10/09/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var txtNewHeight:CGFloat = 0
class InquiryPopupVC: CustomVC {
    
    @IBOutlet var scrollHeight:NSLayoutConstraint!
    @IBOutlet var txtDescription1:UITextView!
    @IBOutlet var txtDesHeight1:NSLayoutConstraint!
    
    @IBOutlet var txtDescription2:UITextView!
    @IBOutlet var txtDesHeight2:NSLayoutConstraint!
    
    var mainView:UIView!
    var arraySearch:[String] = []
    var storeInquiryModel:SCInquiryModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(updateTextView(_:)), name: .descriptionHeightChange, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        txtDescription1.text = "Description"
        txtDescription2.text = "Description"
        
        self.mainView = self.addPopUpEffect
        mainView.scaleAnimation(fromValue: 0.0, toValue: 1.0) {
            self.mainView.subviews[2].layer.addBorder(edge: .bottom, color: .groupTableViewBackground, thickness: 1.0)
        }
        
        if let lblTitle:UILabel = self.mainView.subviews[2] as? UILabel {
            lblTitle.text = "Name : " + selectedCoachData.strInstituteName
        }
        
        mainView.subviews[0].isHidden = studentID != nil
        mainView.subviews[1].isHidden = studentID == nil
        scrollHeight.constant = studentID == nil ? 350 : 160
        self.changeHeightOfTextView(txtDescription1)
        
        if(studentID != nil) {
            if let data = UserDefaults.standard.value(forKey: "UserData") as? Data {
                if let inquiryModel = NSKeyedUnarchiver.unarchiveObject(with: data) as? SCInquiryModel {
                    self.storeInquiryModel = inquiryModel
                    (self.mainView.subviews[1].subviews[0] as? UITextField)?.text = self.storeInquiryModel.strFirstName + " " + self.storeInquiryModel.strLastName
                }
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        (self.mainView.subviews[0].subviews.filter{$0 is UITextField} as! [UITextField]).forEach{$0.text = nil}
        (self.mainView.subviews[1].subviews.filter{$0 is UITextField} as! [UITextField]).forEach{$0.text = nil}
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension InquiryPopupVC
{
    @IBAction func btnSendAction(_ sender:UIButton)
    {
        if(studentID == nil) {
            let textFields:[UITextField] = self.mainView.subviews[0].subviews.filter{$0 is UITextField} as! [UITextField]
            textFields.forEach{$0.setUpBorder(.darkGray)}
            
            let inquiryModel = SCInquiryModel(fname: textFields[0].text!, lname: textFields[1].text!, email: textFields[2].text!, pwd: textFields[3].text!, pno: textFields[4].text!, des: txtDescription1.text!, board: strSelectedBoard, std: strSelectedStd, subject: strSelectedLesson, exam: strSelectedExam, activity: strSelectedActivity, date: "")
            
            let erroTypes:[ErrorType] = [.firstName, .lastName, .email, .password, .phoneNumber]
            
            let result = SCInquiryModel.inquiryValidation(Mirror(reflecting: inquiryModel), erroTypes)
            
            if result.0 {
                self.callInquiryApi(inquiryModel)
            }else{
                textFields[result.1].showErrorView
            }
        }else {
            self.callInquiryApi(storeInquiryModel)
        }
    }
    
    func callInquiryApi(_ inquiryModel:SCInquiryModel)
    {
        let txtView:UITextView = studentID == nil ? txtDescription1 : txtDescription2
        let params = ["Coach_ID" : strCoachID!,
                      "FirstName" : inquiryModel.strFirstName,
                      "LastName" : inquiryModel.strLastName,
                      "PhoneNumber" : inquiryModel.strPhone,
                      "EmailAddress" : inquiryModel.strEmail,
                      "Password" : inquiryModel.strPassword,
                      "Description" : txtView.text.removingWhitespaces() == "Description" ? "" : txtView.text!,
                      "Subject" : strSelectedLesson,
                      "Board" : strSelectedBoard,
                      "Standard" : strSelectedStd,
                      "Activity" : strSelectedActivity,
                      "EntranceTest" : strSelectedExam]
        
        self.callAddUserInquiry(params, completion: {
            showAlertWithOkButton(["", "Thank you for your inquiry"], completion: {
                
                let sinquiryModel:SCInquiryModel = SCInquiryModel.init(fname: inquiryModel.strFirstName, lname: inquiryModel.strLastName, email: inquiryModel.strEmail, pwd: inquiryModel.strPassword, pno: inquiryModel.strPhone)
                
                let encodedData = NSKeyedArchiver.archivedData(withRootObject: sinquiryModel)
                UserDefaults.standard.set(encodedData, forKey: "UserData")
                
                UserDefaults.standard.set(inquiryModel.strFirstName + " " + inquiryModel.strLastName, forKey: "UserName")
                UserDefaults.standard.set("0", forKey: "StudentID") // Its Dummy Value only for condition check
                
                let btnClose:UIButton = self.view.subviews[0].subviews[1] as! UIButton
                self.btnCloseClicked(btnClose)
            })
        })
    }
}

extension InquiryPopupVC
{
    @objc func updateTextView(_ notification:NSNotification)
    {
        let textView:UITextView = notification.userInfo!["TextView"] as! UITextView
        self.changeHeightOfTextView(textView)
    }
    
    func changeHeightOfTextView(_ textView:UITextView)
    {
        let fixedWidth: CGFloat = textView.frame.size.width
        let newSize: CGSize = textView.sizeThatFits(CGSize(width: fixedWidth, height:CGFloat.greatestFiniteMagnitude))
        
        let value:CGFloat = mainView.frame.origin.y
        let compareValue = textView.frame.origin.y + value
        
        if(compareValue > keyboardActualSize.height) {
            (textView.superview as! UIScrollView).setContentOffset(CGPoint(x:0, y: compareValue - keyboardActualSize.height), animated: false)
        }
        else {
            (textView.superview as! UIScrollView).setContentOffset(.zero, animated: false)
        }
        
        txtNewHeight = newSize.height
        if(studentID == nil) {
            if(txtNewHeight < 100){
                self.txtDesHeight1.constant = txtNewHeight
            }else {
                self.txtDesHeight1.constant = 100
            }
        }else{
            if(txtNewHeight < 100){
                self.txtDesHeight2.constant = txtNewHeight
            }else {
                self.txtDesHeight2.constant = 100
            }
        }
    }
}

extension InquiryPopupVC
{
    // TODO: - AutoCompleteMenu
    
    func addAutoCompleteMenu()
    {
        for view in self.mainView.subviews[0].subviews.filter({($0.isKind(of: DropDownTextField.classForCoder()))}) {
            
            let dropDownTextField:DropDownTextField = view as! DropDownTextField
            activateField = dropDownTextField
            
            dropDownTextField.dropDownTableView.tag = 1
            dropDownTextField.dropDownTableView.dataSource = self
            dropDownTextField.dropDownTableView.delegate = self
            
            dropDownTextField.dropDownTableView.isHidden = true
            dropDownTextField.addTarget(self, action: #selector(textFieldDidBegin(_:)), for: .editingDidBegin)
            dropDownTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
            
            arrBoardSearchData =  selectedCoachData.strBoard.isEmptyStr ? [] : selectedCoachData.strBoard.components(separatedBy: ",")
            arrStdSearchData = selectedCoachData.strStandard.isEmptyStr ? [] : selectedCoachData.strStandard.components(separatedBy: ",")
            arrLessonSearchData = selectedCoachData.strSubject.isEmptyStr ? [] : selectedCoachData.strSubject.components(separatedBy: ",")
            arrExamSearchData = selectedCoachData.strExam.isEmptyStr ? [] : selectedCoachData.strExam.components(separatedBy: ",")
            arrActivitySearchData = selectedCoachData.strActivity.isEmptyStr ? [] : selectedCoachData.strActivity.components(separatedBy: ",")
        }
    }
}

extension InquiryPopupVC: UITextFieldDelegate
{
    @objc func textFieldDidBegin(_ textField: DropDownTextField)
    {
        if activateField.dropDownTableView.isHidden == false {
            activateField.dropDownTableView.isHidden = true
        }
        
        activateField = textField
        arraySearch = []
        
        switch textField.placeholder! {
        case "Board":
            arraySearch = arrBoardSearchData.map { $0 }
            arrBoardData = arrBoardSearchData.map { $0 }
            
        case "Standard":
            arraySearch = arrStdSearchData.map { $0 }
            arrStdData = arrStdSearchData.map { $0 }
            
        case "Subject":
            arraySearch = arrLessonSearchData.map { $0 }
            arrLessonData = arrLessonSearchData.map { $0 }
            
        case "Entrance Test":
            arraySearch = arrExamSearchData.map { $0 }
            arrExamData = arrExamSearchData.map { $0 }
            
        case "Activity":
            arraySearch = arrActivitySearchData.map { $0 }
            arrActivityData = arrActivitySearchData.map { $0 }
            
        default:
            break
        }
        
        if(arraySearch.count == 0){
            textField.dropDownTableView.isHidden = true
            return
        }
        textField.dropDownTableView.setUpTblHeight(arraySearch)
        textField.dropDownTableView.isHidden = false
    }
    
    @objc func textFieldDidChange(_ textField: DropDownTextField) {
        
        var array:[String] = []
        let filtered = arraySearch.filter { $0.range(of: textField.text!, options: .caseInsensitive) != nil }
        array = textField.text == "" ? [] : filtered
        
        switch textField.placeholder! {
        case "Board":
            arrBoardData = array.map { $0 }
        case "Standard":
            arrStdData = array.map { $0 }
        case "Subject":
            arrLessonData = array.map { $0 }
        case "Entrance Test":
            arrExamData = array.map { $0 }
        case "Activity":
            arrActivityData = array.map { $0 }
        default:
            break
        }
        
        if(array.count == 0){
            textField.dropDownTableView.isHidden = true
            return
        }
        textField.dropDownTableView.setUpTblHeight(array)
        textField.dropDownTableView.isHidden = false
    }
}

extension InquiryPopupVC: UITableViewDataSource, UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch activateField.placeholder! {
        case "Board":
            return arrBoardData.count
        case "Standard":
            return arrStdData.count
        case "Subject":
            return arrLessonData.count
        case "Entrance Test":
            return arrExamData.count
        case "Activity":
            return arrActivityData.count
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = activateField.dropDownTableView.dequeueReusableCell(withIdentifier: "Cell")
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "Cell")
            cell?.selectionStyle = .none
        }
        
        var array:[String] = []
        switch activateField.placeholder! {
        case "Board":
            array = arrBoardData
        case "Standard":
            array = arrStdData
        case "Subject":
            array = arrLessonData
        case "Entrance Test":
            array = arrExamData
        case "Activity":
            array = arrActivityData
        default:
            break
        }
        
        cell?.textLabel?.font = FontHelper.regular(size: DeviceType.isIpad ? 15 :12)
        cell!.textLabel!.attributedText = array[indexPath.row].makeBoldSubString(activateField.text!, FontHelper.bold(size: DeviceType.isIpad ? 15 :12), false, .black, .black)
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = activateField.dropDownTableView.cellForRow(at: indexPath)
        activateField.text = cell?.textLabel?.text
        self.dismissPicker()
    }
}


