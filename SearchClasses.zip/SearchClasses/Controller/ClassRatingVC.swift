//
//  RatingVC.swift
//  Search Classes
//
//  Created by ADMS on 01/05/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

protocol ClassRatingDelegate {
    func setRating(_ idx:NSInteger, _ rating:Double, _ comment:String)
}

class ClassRatingVC: CustomVC {
    
    @IBOutlet var scrollHeight:NSLayoutConstraint!
    
    @IBOutlet var floatRatingView1: FloatRatingView!
    @IBOutlet var floatRatingView2: FloatRatingView!
    
    @IBOutlet var txtReview1: UITextView!
    @IBOutlet var txtReview2: UITextView!
    
    var lblRating:UILabel!
    var delegate:ClassRatingDelegate?
    var idx = 0
    var ratingValue:Double = 0
    var mainView:UIView!
    var storeInquiryModel:SCInquiryModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.mainView = self.addPopUpEffect
        mainView.scaleAnimation(fromValue: 0.0, toValue: 1.0) {
            self.mainView.subviews[2].layer.addBorder(edge: .bottom, color: .groupTableViewBackground, thickness: 1.0)
        }
        
        txtReview1.text = "Add Comments"
        txtReview2.text = "Add Comments"
        
        ratingValue = 0
        floatRatingView1.rating = ratingValue
        floatRatingView1.delegate = self
        floatRatingView1.type = .halfRatings
        
        floatRatingView2.rating = ratingValue
        floatRatingView2.delegate = self
        floatRatingView2.type = .halfRatings
        
        lblRating = mainView.subviews[studentID == nil ? 0 : 1].viewWithTag(6) as! UILabel
        setRating(ratingValue)
        
        mainView.subviews[0].isHidden = studentID != nil
        mainView.subviews[1].isHidden = studentID == nil
        scrollHeight.constant = studentID == nil ? 400 : 330
        
        if(studentID != nil) {
            if let data = UserDefaults.standard.value(forKey: "UserData") as? Data {
                if let inquiryModel = NSKeyedUnarchiver.unarchiveObject(with: data) as? SCInquiryModel {
                    self.storeInquiryModel = inquiryModel
                    (self.mainView.subviews[1].subviews[0] as? UITextField)?.text = self.storeInquiryModel.strFirstName + " " + self.storeInquiryModel.strLastName
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ClassRatingVC
{
    @IBAction func confirmCancelAction(_ sender:UIButton)
    {
        guard sender.tag != 3 else {
            let btnClose:UIButton = self.view.subviews[0].subviews[1] as! UIButton
            self.btnCloseClicked(btnClose)
            return
        }
        
        if(studentID == nil) {
            let textFields:[UITextField] = self.mainView.subviews[0].subviews.filter{$0 is UITextField} as! [UITextField]
            textFields.forEach{$0.setUpBorder(.darkGray)}
            
            let inquiryModel = SCInquiryModel(fname: textFields[0].text!, lname: textFields[1].text!, email: textFields[2].text!, pwd: textFields[3].text!, pno: textFields[4].text!, des: txtReview1.text!, board: "", std: "", subject: "", exam: "", activity: "", date: "")
            
            let erroTypes:[ErrorType] = [.firstName, .lastName, .email, .password, .phoneNumber]
            
            let result = SCInquiryModel.inquiryValidation(Mirror(reflecting: inquiryModel), erroTypes)
            
            if result.0 {
                self.callRatingApi(inquiryModel)
            }else{
                textFields[result.1].showErrorView
            }
        }else {
            self.callRatingApi(storeInquiryModel)
        }
    }
    
    func callRatingApi(_ inquiryModel:SCInquiryModel)
    {
        guard ratingValue != 0 else {
            showToast(MessageType.noRating.rawValue)
            return
        }
        
        let txtView:UITextView = studentID == nil ? txtReview1 : txtReview2
        
        let params = ["Coach_ID" : strCoachID!,
                      "FirstName" : inquiryModel.strFirstName,
                      "LastName" : inquiryModel.strLastName,
                      "PhoneNumber" : inquiryModel.strPhone,
                      "EmailAddress" : inquiryModel.strEmail,
                      "Password" : inquiryModel.strPassword,
                      "Comment" : txtView.text.removingWhitespaces() == "Add Comments" ? "" : txtView.text!,
                      "RatingValue" : "\(self.ratingValue)"]
        
        self.callAddUserRating(params, completion: { rateAvg in
            showAlertWithOkButton(["", "Thank you for giving rating"], completion: {
                
                self.delegate?.setRating(self.idx, rateAvg, params["Comment"]!)
                
                let sinquiryModel:SCInquiryModel = SCInquiryModel.init(fname: inquiryModel.strFirstName, lname: inquiryModel.strLastName, email: inquiryModel.strEmail, pwd: inquiryModel.strPassword, pno: inquiryModel.strPhone)
                
                let encodedData = NSKeyedArchiver.archivedData(withRootObject: sinquiryModel)
                UserDefaults.standard.set(encodedData, forKey: "UserData")
                
                UserDefaults.standard.set(inquiryModel.strFirstName + " " + inquiryModel.strLastName, forKey: "UserName")
                UserDefaults.standard.set("0", forKey: "StudentID") // Its Dummy Value only for condition check
                
                let btnClose:UIButton = self.view.subviews[0].subviews[1] as! UIButton
                self.btnCloseClicked(btnClose)
            })
        })
    }
}

extension ClassRatingVC: FloatRatingViewDelegate
{
    // MARK: FloatRatingViewDelegate
    
    func floatRatingView(_ ratingView: FloatRatingView, isUpdating rating: Double) {
        setRating(rating)
    }
    
    func floatRatingView(_ ratingView: FloatRatingView, didUpdate rating: Double) {
        setRating(rating)
    }
    
    func setRating(_ rating:Double)
    {
        ratingValue = rating
        var ratingScale:RatingScale = .none
        var textColor = GetColor.radioColorRed
        
        switch Int(floor(rating)) {
        case 1:
            ratingScale = .veryPoor
        case 2:
            ratingScale = .poor
        case 3:
            textColor = GetColor.radioColorOrange
            ratingScale = .average
        case 4:
            textColor = GetColor.radioColorGreen
            ratingScale = .good
        case 5:
            textColor = GetColor.radioColorGreen
            ratingScale = .excellent
        default:
            break
        }
        lblRating.text = ratingScale.rawValue
        lblRating.textColor = textColor
    }
}
